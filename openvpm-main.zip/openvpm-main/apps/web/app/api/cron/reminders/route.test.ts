import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { readFileSync } from "node:fs";

const mocks = vi.hoisted(() => {
  const selectResults: unknown[][] = [];
  const eligibilityResults: unknown[][] = [];
  const recipientResults: unknown[][] = [];
  // Results for the pre-provider claim fence (select id ... for update).
  // Default: the claim still owns the reminder.
  const fenceResults: unknown[][] = [];
  const select = vi.fn((fields?: Record<string, unknown>) => {
    const isFence =
      Object.keys(fields ?? {}).length === 1 &&
      Object.prototype.hasOwnProperty.call(fields ?? {}, "id");
    const result = isFence
      ? (fenceResults.shift() ?? [{ id: "comm-1" }])
      : Object.prototype.hasOwnProperty.call(
      fields ?? {},
      "dispatchEligible",
    )
      ? (eligibilityResults.shift() ?? [{ dispatchEligible: true }])
      : Object.prototype.hasOwnProperty.call(fields ?? {}, "recipientEmail")
        ? (recipientResults.shift() ?? [
            {
              recipientEmail: "ada@lovelacevet.com",
              suppressionReason: null,
              clientFirstName: "Ada",
              clientLastName: "Lovelace",
              patientName: "Miso",
              practiceName: "Neighborhood Veterinary",
              practicePhone: "555-0100",
            },
          ])
        : (selectResults.shift() ?? []);
    const afterWhere: {
      limit: ReturnType<typeof vi.fn>;
      orderBy: ReturnType<typeof vi.fn>;
      for: ReturnType<typeof vi.fn>;
      then: (
        resolve: (value: unknown[]) => unknown,
        reject?: (error: unknown) => unknown,
      ) => Promise<unknown>;
    } = {
      limit: vi.fn(() =>
        Object.assign(Promise.resolve(result), {
          for: vi.fn(async () => result),
        }),
      ),
      orderBy: vi.fn(async () => result),
      for: vi.fn(() => afterWhere),
      then: (
        resolve: (value: unknown[]) => unknown,
        reject?: (error: unknown) => unknown,
      ) => Promise.resolve(result).then(resolve, reject),
    };
    const builder = {
      from: vi.fn(() => builder),
      leftJoin: vi.fn(() => builder),
      innerJoin: vi.fn(() => builder),
      where: vi.fn(() => afterWhere),
      orderBy: vi.fn(async () => result),
      limit: vi.fn(async () => result),
    };
    return builder;
  });

  const claimResults: unknown[][] = [];
  const insertReturning = vi.fn(
    async () => claimResults.shift() ?? [{ id: "comm-1" }],
  );
  const insertOnConflict = vi.fn(() => ({ returning: insertReturning }));
  const insertValues = vi.fn(() => ({ onConflictDoNothing: insertOnConflict }));
  const insert = vi.fn(() => ({ values: insertValues }));
  // Results for the claim's reclaim UPDATE ... RETURNING (failed or stale
  // pending rows). Default: nothing reclaimable.
  const reclaimResults: unknown[][] = [];
  let lastSet: Record<string, unknown> = {};
  // The SMS-to-email switch succeeds by default; other updates read from
  // reclaimResults.
  const updateReturning = vi.fn(async () =>
    Object.keys(lastSet).sort().join(",") === "channel,updatedAt"
      ? [{ id: "comm-1" }]
      : (reclaimResults.shift() ?? []),
  );
  const updateWhere = vi.fn(() => {
    const done = Promise.resolve(undefined);
    return {
      returning: updateReturning,
      then: (
        resolve: (value: undefined) => unknown,
        reject?: (error: unknown) => unknown,
      ) => done.then(resolve, reject),
    };
  });
  const updateSet = vi.fn((values: Record<string, unknown>) => {
    lastSet = values;
    return { where: updateWhere };
  });
  const update = vi.fn(() => ({ set: updateSet }));
  const deleteResults: unknown[][] = [];
  const deleteReturning = vi.fn(
    async () => deleteResults.shift() ?? [{ id: "old-claim" }],
  );
  const deleteWhere = vi.fn(() => ({ returning: deleteReturning }));
  const deleteRows = vi.fn(() => ({ where: deleteWhere }));
  const db = { select, insert, update, delete: deleteRows };

  return {
    db,
    selectResults,
    eligibilityResults,
    recipientResults,
    fenceResults,
    claimResults,
    reclaimResults,
    updateReturning,
    deleteResults,
    insertValues,
    insertOnConflict,
    insertReturning,
    updateSet,
    updateWhere,
    deleteRows,
    deleteWhere,
    deleteReturning,
    sendAppointmentReminder: vi.fn(),
    sendAppointmentReminderSms: vi.fn(),
    lockPracticeForExternalSideEffects: vi.fn(async () => true),
    alertOps: vi.fn(async () => undefined),
    cronAuthError: vi.fn(() => null),
    withSystem: vi.fn(async (_db: unknown, fn: (tx: unknown) => unknown) =>
      fn(db),
    ),
    withTenant: vi.fn(
      async (_db: unknown, _practiceId: string, fn: (tx: unknown) => unknown) =>
        fn(db),
    ),
  };
});

vi.mock("@openpims/db/client", () => ({
  db: mocks.db,
}));

vi.mock("@/lib/tenant-db", () => ({
  withSystem: mocks.withSystem,
  withTenant: mocks.withTenant,
}));

vi.mock("@/lib/email", () => ({
  sendAppointmentReminder: mocks.sendAppointmentReminder,
}));

vi.mock("@/lib/sms", () => ({
  sendAppointmentReminderSms: mocks.sendAppointmentReminderSms,
}));

vi.mock("@/lib/alerts", () => ({
  alertOps: mocks.alertOps,
}));

vi.mock("@/lib/recovery-hold", () => ({
  lockPracticeForExternalSideEffects:
    mocks.lockPracticeForExternalSideEffects,
}));

vi.mock("@/lib/cron-auth", () => ({
  cronAuthError: mocks.cronAuthError,
}));

const { GET } = await import("./route");

const PRACTICE_ID = "00000000-0000-0000-0000-0000000000aa";
const CLIENT_ID = "00000000-0000-0000-0000-000000000001";
const LOCATION_ID = "00000000-0000-0000-0000-000000000002";
const APPOINTMENT_ID = "00000000-0000-0000-0000-000000000003";

let consoleLog: { mockRestore: () => void } | undefined;

function appointment(overrides: Record<string, unknown> = {}) {
  return {
    id: APPOINTMENT_ID,
    startTime: new Date("2026-07-02T16:00:00Z"),
    endTime: new Date("2026-07-02T16:30:00Z"),
    practiceId: PRACTICE_ID,
    patientName: "Miso",
    clientId: CLIENT_ID,
    clientFirstName: "Ada",
    clientLastName: "Lovelace",
    clientEmail: "ada@lovelacevet.com",
    emailSuppressionReason: null,
    clientPhone: "(555) 555-0100",
    preferredContactMethod: "sms",
    smsConsent: true,
    doctorName: "Dr. Vet",
    practiceName: "Neighborhood Veterinary",
    practicePhone: "555-0100",
    practiceTimezone: "America/New_York",
    locationId: null,
    ...overrides,
  };
}

beforeEach(() => {
  vi.useFakeTimers();
  vi.setSystemTime(new Date("2026-07-01T16:00:00Z"));
  consoleLog = vi.spyOn(console, "log").mockImplementation(() => undefined);
  mocks.sendAppointmentReminder.mockResolvedValue({ success: true });
  mocks.sendAppointmentReminderSms.mockResolvedValue({ success: true });
});

afterEach(() => {
  consoleLog?.mockRestore();
  consoleLog = undefined;
  vi.useRealTimers();
  vi.clearAllMocks();
  mocks.selectResults.length = 0;
  mocks.eligibilityResults.length = 0;
  mocks.recipientResults.length = 0;
  mocks.fenceResults.length = 0;
  mocks.claimResults.length = 0;
  mocks.reclaimResults.length = 0;
  mocks.deleteResults.length = 0;
});

describe("appointment reminder cron", () => {
  it("does not send when active recipient joins filter out every appointment", async () => {
    mocks.selectResults.push([]);

    const response = await GET(
      new Request("https://openvpm.test/api/cron/reminders"),
    );

    await expect(response.json()).resolves.toEqual({
      sent: 0,
      failed: 0,
      skipped: 0,
      deduped: 0,
      suppressed: 0,
    });
    expect(mocks.sendAppointmentReminderSms).not.toHaveBeenCalled();
    expect(mocks.sendAppointmentReminder).not.toHaveBeenCalled();
    expect(mocks.insertValues).not.toHaveBeenCalled();
  });

  it("does not claim or dispatch an appointment that becomes ineligible after the sweep", async () => {
    mocks.selectResults.push([appointment()]);
    mocks.eligibilityResults.push([]);

    const response = await GET(
      new Request("https://openvpm.test/api/cron/reminders"),
    );

    await expect(response.json()).resolves.toEqual({
      sent: 0,
      failed: 0,
      skipped: 0,
      deduped: 0,
      suppressed: 0,
    });
    expect(mocks.insertValues).not.toHaveBeenCalled();
    expect(mocks.sendAppointmentReminder).not.toHaveBeenCalled();
    expect(mocks.sendAppointmentReminderSms).not.toHaveBeenCalled();
    expect(consoleLog).toHaveBeenCalledWith(
      expect.stringContaining("1 no longer eligible"),
    );
  });

  it("suppresses seeded demo appointments before any provider or delivery claim", async () => {
    mocks.selectResults.push([
      appointment({
        isSeededDemoAppointment: true,
      }),
    ]);

    const response = await GET(
      new Request("https://openvpm.test/api/cron/reminders"),
    );

    await expect(response.json()).resolves.toEqual({
      sent: 0,
      failed: 0,
      skipped: 0,
      deduped: 0,
      suppressed: 1,
    });
    expect(mocks.sendAppointmentReminderSms).not.toHaveBeenCalled();
    expect(mocks.sendAppointmentReminder).not.toHaveBeenCalled();
    expect(mocks.insertValues).not.toHaveBeenCalled();
    expect(consoleLog).toHaveBeenCalledWith(
      "Cron reminders completed: 0 sent, 0 failed, 0 deferred (quiet hours), 0 deduped, 0 no longer eligible, 1 suppressed (1 demo, 0 reserved address) out of 1 total",
    );
    expect(consoleLog).not.toHaveBeenCalledWith(
      expect.stringContaining("Miso"),
    );
    expect(consoleLog).not.toHaveBeenCalledWith(
      expect.stringContaining("lovelacevet.com"),
    );
  });

  it("suppresses reserved fixture email domains even when SMS is preferred", async () => {
    mocks.selectResults.push([
      appointment({
        clientEmail: " ada@reminders.openvpm.test ",
      }),
    ]);

    const response = await GET(
      new Request("https://openvpm.test/api/cron/reminders"),
    );

    await expect(response.json()).resolves.toEqual({
      sent: 0,
      failed: 0,
      skipped: 0,
      deduped: 0,
      suppressed: 1,
    });
    expect(mocks.sendAppointmentReminderSms).not.toHaveBeenCalled();
    expect(mocks.sendAppointmentReminder).not.toHaveBeenCalled();
    expect(mocks.insertValues).not.toHaveBeenCalled();
    expect(consoleLog).toHaveBeenCalledWith(
      "Cron reminders completed: 0 sent, 0 failed, 0 deferred (quiet hours), 0 deduped, 0 no longer eligible, 1 suppressed (0 demo, 1 reserved address) out of 1 total",
    );
  });

  it("uses an active practice sender for scheduled SMS reminders", async () => {
    mocks.sendAppointmentReminderSms.mockResolvedValueOnce({
      success: true,
      sid: "sms-cron-1",
    });
    mocks.selectResults.push(
      [
        appointment({
          startTime: new Date("2026-07-02T16:00:00Z"),
          practiceTimezone: " America/Los_Angeles ",
          locationId: LOCATION_ID,
        }),
      ],
      [{ locationId: LOCATION_ID }],
    );

    const response = await GET(
      new Request("https://openvpm.test/api/cron/reminders"),
    );

    await expect(response.json()).resolves.toEqual({
      sent: 1,
      failed: 0,
      skipped: 0,
      deduped: 0,
      suppressed: 0,
    });
    expect(mocks.sendAppointmentReminderSms).toHaveBeenCalledWith(
      expect.objectContaining({
        to: "(555) 555-0100",
        appointmentDate: "Thursday, July 2, 2026",
        appointmentTime: "9:00 AM",
        practiceId: PRACTICE_ID,
        locationId: LOCATION_ID,
        clientId: CLIENT_ID,
      }),
    );
    expect(mocks.insertValues).toHaveBeenCalledWith(
      expect.objectContaining({
        practiceId: PRACTICE_ID,
        clientId: CLIENT_ID,
        channel: "sms",
        status: "pending",
        dedupeKey: `reminder:appointment:${APPOINTMENT_ID}:2026-07-02T16:00:00.000Z`,
      }),
    );
    expect(mocks.insertOnConflict).toHaveBeenCalled();
    expect(mocks.updateSet).toHaveBeenCalledWith(
      expect.objectContaining({
        channel: "sms",
        status: "sent",
        providerMessageId: "sms-cron-1",
      }),
    );
  });

  it("falls back to email when scheduled SMS has no active sender", async () => {
    mocks.sendAppointmentReminder.mockResolvedValueOnce({
      success: true,
      id: "email-cron-1",
    });
    mocks.selectResults.push(
      [appointment({ clientEmail: " Ada@LovelaceVet.COM " })],
      [],
    );

    const response = await GET(
      new Request("https://openvpm.test/api/cron/reminders"),
    );

    await expect(response.json()).resolves.toEqual({
      sent: 1,
      failed: 0,
      skipped: 0,
      deduped: 0,
      suppressed: 0,
    });
    expect(mocks.sendAppointmentReminderSms).not.toHaveBeenCalled();
    expect(mocks.sendAppointmentReminder).toHaveBeenCalledWith(
      expect.objectContaining({ to: "ada@lovelacevet.com" }),
    );
    expect(mocks.insertValues).toHaveBeenCalledWith(
      expect.objectContaining({
        practiceId: PRACTICE_ID,
        clientId: CLIENT_ID,
        channel: "sms",
        status: "pending",
      }),
    );
    expect(mocks.updateSet).toHaveBeenCalledWith(
      expect.objectContaining({
        channel: "email",
        status: "sent",
        providerMessageId: "email-cron-1",
      }),
    );
  });

  it("uses email directly when the preferred SMS phone is invalid", async () => {
    mocks.sendAppointmentReminder.mockResolvedValueOnce({
      success: true,
      id: "email-cron-2",
    });
    mocks.selectResults.push([
      appointment({
        clientEmail: " Ada@LovelaceVet.COM ",
        clientPhone: "12345",
      }),
    ]);

    const response = await GET(
      new Request("https://openvpm.test/api/cron/reminders"),
    );

    await expect(response.json()).resolves.toEqual({
      sent: 1,
      failed: 0,
      skipped: 0,
      deduped: 0,
      suppressed: 0,
    });
    expect(mocks.sendAppointmentReminderSms).not.toHaveBeenCalled();
    expect(mocks.sendAppointmentReminder).toHaveBeenCalledWith(
      expect.objectContaining({ to: "ada@lovelacevet.com" }),
    );
    expect(mocks.insertValues).toHaveBeenCalledWith(
      expect.objectContaining({
        practiceId: PRACTICE_ID,
        clientId: CLIENT_ID,
        channel: "email",
        status: "pending",
      }),
    );
    expect(mocks.updateSet).toHaveBeenCalledWith(
      expect.objectContaining({
        channel: "email",
        status: "sent",
        providerMessageId: "email-cron-2",
      }),
    );
  });

  it("defers SMS-only scheduled reminders during quiet hours with padded timezones", async () => {
    vi.setSystemTime(new Date("2026-07-02T02:30:00Z"));
    mocks.selectResults.push([
      appointment({
        clientEmail: null,
        practiceTimezone: " America/New_York ",
      }),
    ]);

    const response = await GET(
      new Request("https://openvpm.test/api/cron/reminders"),
    );

    await expect(response.json()).resolves.toEqual({
      sent: 0,
      failed: 0,
      skipped: 1,
      deduped: 0,
      suppressed: 0,
    });
    expect(mocks.insertValues).not.toHaveBeenCalled();
    expect(mocks.sendAppointmentReminderSms).not.toHaveBeenCalled();
    expect(mocks.sendAppointmentReminder).not.toHaveBeenCalled();
  });

  it("blocks scheduled email reminders to provider-suppressed recipients", async () => {
    mocks.recipientResults.push([
      {
        recipientEmail: "ada@lovelacevet.com",
        suppressionReason: "bounce",
        clientFirstName: "Ada",
        clientLastName: "Lovelace",
        patientName: "Miso",
        practiceName: "Neighborhood Veterinary",
      },
    ]);
    mocks.selectResults.push([
      appointment({
        preferredContactMethod: "email",
        clientPhone: null,
        smsConsent: false,
        emailSuppressionReason: "bounce",
      }),
    ]);

    const response = await GET(
      new Request("https://openvpm.test/api/cron/reminders"),
    );

    await expect(response.json()).resolves.toEqual({
      sent: 0,
      failed: 1,
      skipped: 0,
      deduped: 0,
      suppressed: 0,
    });
    expect(mocks.sendAppointmentReminder).not.toHaveBeenCalled();
    expect(mocks.insertValues).toHaveBeenCalledWith(
      expect.objectContaining({
        practiceId: PRACTICE_ID,
        clientId: CLIENT_ID,
        channel: "email",
        status: "pending",
      }),
    );
    expect(mocks.updateSet).toHaveBeenCalledWith(
      expect.objectContaining({
        channel: "email",
        status: "failed",
        content: expect.stringContaining(
          "Client email is suppressed after a delivery bounce",
        ),
      }),
    );
  });

  it("honors an email suppression added after the sweep and before provider dispatch", async () => {
    mocks.selectResults.push([
      appointment({
        preferredContactMethod: "email",
        emailSuppressionReason: null,
      }),
    ]);
    mocks.recipientResults.push([
      {
        recipientEmail: "new-address@example.com",
        suppressionReason: "bounce",
        clientFirstName: "Ada",
        clientLastName: "Lovelace",
        patientName: "Miso",
        practiceName: "Neighborhood Veterinary",
      },
    ]);

    const response = await GET(
      new Request("https://openvpm.test/api/cron/reminders"),
    );

    await expect(response.json()).resolves.toMatchObject({
      sent: 0,
      failed: 1,
    });
    expect(mocks.sendAppointmentReminder).not.toHaveBeenCalled();
    expect(mocks.updateSet).toHaveBeenCalledWith(
      expect.objectContaining({
        channel: "email",
        status: "failed",
        content: expect.stringContaining("delivery bounce"),
      }),
    );
  });

  it("fails SMS-only scheduled reminders when no active sender exists", async () => {
    mocks.recipientResults.push([]);
    mocks.selectResults.push([appointment({ clientEmail: null })], []);

    const response = await GET(
      new Request("https://openvpm.test/api/cron/reminders"),
    );

    await expect(response.json()).resolves.toEqual({
      sent: 0,
      failed: 1,
      skipped: 0,
      deduped: 0,
      suppressed: 0,
    });
    expect(mocks.sendAppointmentReminderSms).not.toHaveBeenCalled();
    expect(mocks.sendAppointmentReminder).not.toHaveBeenCalled();
    expect(mocks.insertValues).toHaveBeenCalledWith(
      expect.objectContaining({
        practiceId: PRACTICE_ID,
        clientId: CLIENT_ID,
        channel: "sms",
        status: "pending",
      }),
    );
    expect(mocks.updateSet).toHaveBeenCalledWith(
      expect.objectContaining({
        channel: "sms",
        status: "failed",
      }),
    );
  });

  it("dedupes already-claimed scheduled reminders before transport", async () => {
    mocks.selectResults.push([appointment()]);
    mocks.claimResults.push([]);

    const response = await GET(
      new Request("https://openvpm.test/api/cron/reminders"),
    );

    await expect(response.json()).resolves.toEqual({
      sent: 0,
      failed: 0,
      skipped: 0,
      deduped: 1,
      suppressed: 0,
    });
    expect(mocks.sendAppointmentReminderSms).not.toHaveBeenCalled();
    expect(mocks.sendAppointmentReminder).not.toHaveBeenCalled();
    // Only the conditional reclaim, the expired email claim check, and the
    // stale unreserved SMS recovery ran; no outcome was projected.
    expect(mocks.updateSet).toHaveBeenCalledTimes(3);
    expect(mocks.updateSet).toHaveBeenNthCalledWith(
      1,
      expect.objectContaining({ status: "pending" }),
    );
    expect(mocks.updateSet).not.toHaveBeenCalledWith(
      expect.objectContaining({ status: "failed" }),
    );
    expect(mocks.updateSet).not.toHaveBeenCalledWith(
      expect.objectContaining({ status: "sent" }),
    );
  });

  it("keeps fresh pending scheduled reminder claims deduped", async () => {
    mocks.selectResults.push(
      [appointment({ preferredContactMethod: "email" })],
      [
        {
          id: "comm-existing",
          status: "pending",
          createdAt: new Date("2026-07-01T15:45:00Z"),
        },
      ],
    );
    mocks.claimResults.push([]);

    const response = await GET(
      new Request("https://openvpm.test/api/cron/reminders"),
    );

    await expect(response.json()).resolves.toEqual({
      sent: 0,
      failed: 0,
      skipped: 0,
      deduped: 1,
      suppressed: 0,
    });
    expect(mocks.deleteRows).not.toHaveBeenCalled();
    expect(mocks.sendAppointmentReminder).not.toHaveBeenCalled();
    expect(mocks.sendAppointmentReminderSms).not.toHaveBeenCalled();
  });

  it("does not re-attempt a failure the sweep itself recorded", async () => {
    mocks.selectResults.push([appointment({ preferredContactMethod: "email" })]);
    mocks.claimResults.push([]);
    // The reclaim UPDATE excludes failures recorded by the automated sweep.
    mocks.reclaimResults.push([]);

    const response = await GET(
      new Request("https://openvpm.test/api/cron/reminders"),
    );

    await expect(response.json()).resolves.toEqual({
      sent: 0,
      failed: 0,
      skipped: 0,
      deduped: 1,
      suppressed: 0,
    });
    expect(mocks.deleteRows).not.toHaveBeenCalled();
    expect(mocks.insertReturning).toHaveBeenCalledOnce();
    expect(mocks.sendAppointmentReminder).not.toHaveBeenCalled();
    expect(mocks.updateSet).not.toHaveBeenCalledWith(
      expect.objectContaining({ status: "sent" }),
    );
  });

  it("sends the automatic reminder after an earlier staff send failed", async () => {
    mocks.selectResults.push([appointment({ preferredContactMethod: "email" })]);
    mocks.claimResults.push([]);
    mocks.reclaimResults.push([{ id: "comm-staff-failed" }]);
    mocks.sendAppointmentReminder.mockResolvedValueOnce({
      success: true,
      id: "email-retry-1",
    });

    const response = await GET(
      new Request("https://openvpm.test/api/cron/reminders"),
    );

    await expect(response.json()).resolves.toEqual({
      sent: 1,
      failed: 0,
      skipped: 0,
      deduped: 0,
      suppressed: 0,
    });
    expect(mocks.sendAppointmentReminder).toHaveBeenCalledOnce();
    expect(mocks.updateSet).toHaveBeenNthCalledWith(
      1,
      expect.objectContaining({
        status: "pending",
        subject: "Automated Appointment Reminder",
        providerMessageId: null,
      }),
    );
    expect(mocks.updateSet).toHaveBeenLastCalledWith(
      expect.objectContaining({
        channel: "email",
        status: "sent",
        providerMessageId: "email-retry-1",
      }),
    );
  });

  it("records the provider's reason when an automatic email fails", async () => {
    mocks.selectResults.push([appointment({ preferredContactMethod: "email" })]);
    mocks.sendAppointmentReminder.mockResolvedValueOnce({
      success: false,
      error: "Mailbox unavailable",
    });

    const response = await GET(
      new Request("https://openvpm.test/api/cron/reminders"),
    );

    await expect(response.json()).resolves.toMatchObject({
      sent: 0,
      failed: 1,
    });
    expect(mocks.updateSet).toHaveBeenLastCalledWith(
      expect.objectContaining({
        status: "failed",
        reminderOutcome: "automated_failure",
        content: expect.stringContaining(
          ": The email provider rejected the reminder.",
        ),
      }),
    );
    // Raw provider text stays in server logs, not the client timeline.
    expect(mocks.updateSet).not.toHaveBeenCalledWith(
      expect.objectContaining({
        content: expect.stringContaining("Mailbox unavailable"),
      }),
    );
    expect(mocks.sendAppointmentReminder).toHaveBeenCalledWith(
      expect.objectContaining({
        idempotencyKey: expect.stringMatching(/^email:reminder:appointment:.*:attempt-1$/),
      }),
    );
  });

  it("never marks an accepted email as failed when recording it throws", async () => {
    mocks.selectResults.push([appointment({ preferredContactMethod: "email" })]);
    mocks.sendAppointmentReminder.mockResolvedValueOnce({
      success: true,
      id: "email-accepted-1",
    });
    vi.spyOn(console, "error").mockImplementation(() => undefined);
    mocks.updateSet.mockImplementationOnce(() => {
      throw new Error("projection unavailable");
    });

    const response = await GET(
      new Request("https://openvpm.test/api/cron/reminders"),
    );

    await expect(response.json()).resolves.toMatchObject({ failed: 1 });
    expect(mocks.updateSet).toHaveBeenCalledOnce();
    expect(mocks.updateSet).not.toHaveBeenCalledWith(
      expect.objectContaining({ status: "failed" }),
    );
  });

  it("marks an email whose provider outcome is unknown as never retryable", async () => {
    mocks.selectResults.push([appointment({ preferredContactMethod: "email" })]);
    mocks.sendAppointmentReminder.mockResolvedValueOnce({
      success: false,
      outcome: "outcome_unknown",
      error: "Email send timed out after 10000ms",
    });

    const response = await GET(
      new Request("https://openvpm.test/api/cron/reminders"),
    );

    await expect(response.json()).resolves.toMatchObject({
      sent: 0,
      failed: 1,
    });
    expect(mocks.updateSet).toHaveBeenLastCalledWith(
      expect.objectContaining({
        status: "pending",
        reminderOutcome: "outcome_unknown",
        content: expect.stringContaining("delivery unknown"),
      }),
    );
  });

  it("records a failed redispatch of an unconfirmed email as delivery unknown", async () => {
    mocks.selectResults.push([appointment({ preferredContactMethod: "email" })]);
    mocks.claimResults.push([]);
    mocks.reclaimResults.push([
      { id: "comm-unknown", attempt: 1, claimToken: "token-2", redispatch: true },
    ]);
    mocks.sendAppointmentReminder.mockResolvedValueOnce({
      success: false,
      outcome: "definite_failure",
      error: "Rejected",
    });
    vi.spyOn(console, "error").mockImplementation(() => undefined);

    const response = await GET(
      new Request("https://openvpm.test/api/cron/reminders"),
    );

    await expect(response.json()).resolves.toMatchObject({ failed: 1 });
    // The first send may have gone out; a failure now proves nothing, so the
    // reminder must never move to a new attempt (and a new key).
    expect(mocks.updateSet).toHaveBeenLastCalledWith(
      expect.objectContaining({
        status: "pending",
        reminderOutcome: "outcome_unknown",
        content: expect.stringContaining("delivery unknown"),
      }),
    );
    expect(mocks.updateSet).not.toHaveBeenCalledWith(
      expect.objectContaining({ status: "failed" }),
    );
  });

  it("records a recovery pause on a redispatch as delivery unknown", async () => {
    mocks.selectResults.push([appointment({ preferredContactMethod: "email" })]);
    mocks.claimResults.push([]);
    mocks.reclaimResults.push([
      { id: "comm-unknown", attempt: 1, claimToken: "token-2", redispatch: true },
    ]);
    mocks.lockPracticeForExternalSideEffects.mockResolvedValueOnce(false);

    const response = await GET(
      new Request("https://openvpm.test/api/cron/reminders"),
    );

    await expect(response.json()).resolves.toMatchObject({ failed: 1 });
    expect(mocks.sendAppointmentReminder).not.toHaveBeenCalled();
    expect(mocks.updateSet).toHaveBeenLastCalledWith(
      expect.objectContaining({
        status: "pending",
        reminderOutcome: "outcome_unknown",
      }),
    );
  });

  it("never sends when another claim took the reminder over", async () => {
    mocks.selectResults.push([appointment({ preferredContactMethod: "email" })]);
    mocks.fenceResults.push([]);

    const response = await GET(
      new Request("https://openvpm.test/api/cron/reminders"),
    );

    await expect(response.json()).resolves.toMatchObject({
      sent: 0,
      failed: 0,
      deduped: 1,
    });
    expect(mocks.sendAppointmentReminder).not.toHaveBeenCalled();
    // The overtaken claim writes nothing over the claim that replaced it.
    expect(mocks.updateSet).not.toHaveBeenCalled();
  });

  it("records delivery unknown when the send transaction fails after the provider accepted", async () => {
    mocks.selectResults.push([appointment({ preferredContactMethod: "email" })]);
    mocks.sendAppointmentReminder.mockResolvedValueOnce({
      success: true,
      id: "email-accepted-before-commit",
    });
    vi.spyOn(console, "error").mockImplementation(() => undefined);
    const passthrough = async (
      _db: unknown,
      _practiceId: string,
      fn: (tx: unknown) => unknown,
    ) => fn(mocks.db);
    mocks.withTenant
      .mockImplementationOnce(passthrough) // claim
      .mockImplementationOnce(passthrough) // current recipient
      .mockImplementationOnce(async (_db, _practiceId, fn) => {
        await fn(mocks.db);
        throw new Error("Connection terminated during COMMIT");
      });

    const response = await GET(
      new Request("https://openvpm.test/api/cron/reminders"),
    );

    await expect(response.json()).resolves.toMatchObject({ sent: 0, failed: 1 });
    expect(mocks.sendAppointmentReminder).toHaveBeenCalledOnce();
    expect(mocks.updateSet).toHaveBeenLastCalledWith(
      expect.objectContaining({
        status: "pending",
        reminderOutcome: "outcome_unknown",
      }),
    );
    expect(mocks.updateSet).not.toHaveBeenCalledWith(
      expect.objectContaining({ status: "failed" }),
    );
  });

  it("records the SMS reason when SMS fails and the client has no email", async () => {
    mocks.selectResults.push([
      appointment({ clientEmail: null, locationId: null }),
    ]);

    const response = await GET(
      new Request("https://openvpm.test/api/cron/reminders"),
    );

    await expect(response.json()).resolves.toMatchObject({ failed: 1 });
    expect(mocks.updateSet).toHaveBeenLastCalledWith(
      expect.objectContaining({
        channel: "sms",
        status: "failed",
        content: expect.stringContaining(
          "No active texting number is set up for this location.",
        ),
      }),
    );
  });

  it("reclaims an abandoned pending email claim", async () => {
    mocks.selectResults.push([appointment({ preferredContactMethod: "email" })]);
    mocks.claimResults.push([]);
    mocks.reclaimResults.push([{ id: "comm-stale" }]);

    const response = await GET(
      new Request("https://openvpm.test/api/cron/reminders"),
    );

    await expect(response.json()).resolves.toEqual({
      sent: 1,
      failed: 0,
      skipped: 0,
      deduped: 0,
      suppressed: 0,
    });
    expect(mocks.deleteRows).not.toHaveBeenCalled();
    expect(mocks.insertReturning).toHaveBeenCalledOnce();
    expect(mocks.sendAppointmentReminder).toHaveBeenCalledOnce();
  });

  it("resends a reclaimed email by email for a client who prefers texts", async () => {
    // An SMS that fell back to email, then was interrupted: the row is an
    // email claim and must be resent by email under its own key.
    mocks.sendAppointmentReminder.mockResolvedValueOnce({
      success: true,
      id: "email-redispatch-1",
      outcome: "accepted",
    });
    mocks.selectResults.push(
      [
        appointment({
          startTime: new Date("2026-07-02T16:00:00Z"),
          locationId: LOCATION_ID,
        }),
      ],
      [{ locationId: LOCATION_ID }],
    );
    mocks.claimResults.push([]);
    mocks.reclaimResults.push([
      {
        id: "comm-fallback",
        channel: "email",
        attempt: 1,
        claimToken: "token-2",
        redispatch: true,
      },
    ]);

    const response = await GET(
      new Request("https://openvpm.test/api/cron/reminders"),
    );

    await expect(response.json()).resolves.toMatchObject({ sent: 1, failed: 0 });
    expect(mocks.insertValues).toHaveBeenCalledWith(
      expect.objectContaining({ channel: "sms" }),
    );
    expect(mocks.sendAppointmentReminderSms).not.toHaveBeenCalled();
    expect(mocks.sendAppointmentReminder).toHaveBeenCalledOnce();
    expect(mocks.sendAppointmentReminder).toHaveBeenCalledWith(
      expect.objectContaining({
        idempotencyKey: `email:reminder:appointment:${APPOINTMENT_ID}:2026-07-02T16:00:00.000Z:attempt-1`,
      }),
    );
    expect(mocks.updateSet).toHaveBeenLastCalledWith(
      expect.objectContaining({
        channel: "email",
        status: "sent",
        providerMessageId: "email-redispatch-1",
      }),
    );
  });

  it("never projects an accepted SMS as failed when status persistence errors", async () => {
    mocks.selectResults.push(
      [appointment({ locationId: LOCATION_ID })],
      [{ locationId: LOCATION_ID }],
    );
    mocks.sendAppointmentReminderSms.mockResolvedValueOnce({
      success: true,
      outcome: "accepted",
      sid: "sms-accepted-1",
      attemptId: "attempt-accepted-1",
      replayed: false,
    });
    mocks.updateWhere.mockRejectedValueOnce(
      new Error("projection unavailable"),
    );

    const response = await GET(
      new Request("https://openvpm.test/api/cron/reminders"),
    );

    await expect(response.json()).resolves.toEqual({
      sent: 0,
      failed: 1,
      skipped: 0,
      deduped: 0,
      suppressed: 0,
    });
    expect(mocks.sendAppointmentReminderSms).toHaveBeenCalledOnce();
    expect(mocks.updateSet).toHaveBeenCalledTimes(1);
    expect(mocks.updateSet).toHaveBeenCalledWith(
      expect.objectContaining({ channel: "sms", status: "sent" }),
    );
    expect(mocks.updateSet).not.toHaveBeenCalledWith(
      expect.objectContaining({ status: "failed" }),
    );
    expect(mocks.alertOps).toHaveBeenCalledWith(
      "Accepted or ambiguous SMS reminder projection failed",
      expect.stringContaining("attempt=attempt-accepted-1"),
    );
  });

  it("marks claimed email reminders failed when the email provider rejects the send", async () => {
    mocks.sendAppointmentReminder.mockResolvedValueOnce({ success: false });
    mocks.selectResults.push([
      appointment({
        preferredContactMethod: "email",
        startTime: new Date("2026-07-02T16:00:00Z"),
        practiceTimezone: "America/Los_Angeles",
      }),
    ]);

    const response = await GET(
      new Request("https://openvpm.test/api/cron/reminders"),
    );

    await expect(response.json()).resolves.toEqual({
      sent: 0,
      failed: 1,
      skipped: 0,
      deduped: 0,
      suppressed: 0,
    });
    expect(mocks.sendAppointmentReminder).toHaveBeenCalledOnce();
    expect(mocks.sendAppointmentReminder).toHaveBeenCalledWith(
      expect.objectContaining({
        appointmentDate: "Thursday, July 2, 2026",
        appointmentTime: "9:00 AM",
      }),
    );
    expect(mocks.updateSet).toHaveBeenCalledWith(
      expect.objectContaining({
        channel: "email",
        status: "failed",
      }),
    );
  });

  it("does not call the email provider if recovery begins after the sweep", async () => {
    mocks.lockPracticeForExternalSideEffects.mockResolvedValueOnce(false);
    mocks.selectResults.push([
      appointment({
        preferredContactMethod: "email",
      }),
    ]);

    const response = await GET(
      new Request("https://openvpm.test/api/cron/reminders"),
    );

    await expect(response.json()).resolves.toEqual({
      sent: 0,
      failed: 1,
      skipped: 0,
      deduped: 0,
      suppressed: 0,
    });
    expect(mocks.sendAppointmentReminder).not.toHaveBeenCalled();
    expect(mocks.updateSet).toHaveBeenCalledWith(
      expect.objectContaining({
        channel: "email",
        status: "failed",
        content: expect.stringContaining("recovery is in progress"),
      }),
    );
  });
});

describe("appointment reminder cron query scoping", () => {
  const source = readFileSync(new URL("./route.ts", import.meta.url), "utf8");
  const claimSource = readFileSync(
    new URL(
      "../../../../lib/messaging/appointment-reminder.ts",
      import.meta.url,
    ),
    "utf8",
  );

  function expectScopedJoin(table: string, foreignKey: string) {
    expect(source).toMatch(
      new RegExp(
        `leftJoin\\(\\s*${table},\\s*and\\(\\s*eq\\(${foreignKey.replace(
          ".",
          "\\.",
        )}, ${table}\\.id\\),\\s*eq\\(${table}\\.practiceId, appointments\\.practiceId\\),\\s*isNull\\(${table}\\.deletedAt\\),?\\s*\\),?\\s*\\)`,
        "s",
      ),
    );
  }

  it("keeps reminder sweep joins scoped to active appointment practices", () => {
    expect(source).toMatch(
      /leftJoin\(\s*patients,\s*and\(\s*eq\(appointments\.patientId, patients\.id\),\s*eq\(patients\.clientId, appointments\.clientId\),\s*eq\(patients\.practiceId, appointments\.practiceId\),\s*isNull\(patients\.deletedAt\),?\s*\),?\s*\)/s,
    );
    expectScopedJoin("clients", "appointments.clientId");
    expectScopedJoin("users", "appointments.doctorId");
    expectScopedJoin("rooms", "appointments.roomId");
    expect(source).toMatch(
      /innerJoin\(\s*practices,\s*and\(\s*eq\(appointments\.practiceId, practices\.id\),\s*isNull\(practices\.deletedAt\),?\s*\),?\s*\)/s,
    );
    expect(source).toContain('eq(appointments.status, "confirmed")');
    expect(source).toContain("eq(practices.appointmentRemindersEnabled, true)");
    expect(source).toContain("practices.appointmentReminderLeadHours");
    expect(source).toContain("interval '1 hour'");
    expect(source).toContain("now.toISOString()}::timestamptz");
    expect(source).not.toContain("sql`${now} +");
    expect(source).not.toContain(
      'inArray(appointments.status, ["scheduled", "confirmed"])',
    );
  });

  it("revalidates clinic and appointment state inside the tenant claim", () => {
    expect(source).toContain("appointmentReminderDispatchEligible(tx");
    expect(claimSource).toContain(
      "eq(practices.appointmentRemindersEnabled, true)",
    );
    expect(claimSource).toContain('eq(appointments.status, "confirmed")');
    expect(claimSource).toContain(
      "eq(appointments.startTime, options.startTime)",
    );
    expect(claimSource).toContain("practices.appointmentReminderLeadHours");
    expect(claimSource).toContain("options.now.toISOString()}::timestamptz");
    expect(claimSource).not.toContain("sql`${options.now} +");
    expect(claimSource).toContain("isNull(appointments.deletedAt)");
    expect(source).toContain("currentAppointmentReminderEmailRecipient(tx");
    expect(claimSource).toContain(
      "sql`${emailSuppressions.email} = lower(trim(${clients.email}))`",
    );
  });

  it("matches provider suppressions against trimmed normalized client emails", () => {
    expect(source).toContain(
      "sql`${emailSuppressions.email} = lower(trim(${clients.email}))`",
    );
    expect(source).not.toContain(
      "sql`${emailSuppressions.email} = lower(${clients.email})`",
    );
  });

  it("projects both demo-data markers needed for pre-provider suppression", () => {
    expect(source).toContain("isSeededDemoClient: sql<boolean>");
    expect(source).toContain("isSeededDemoAppointment: sql<boolean>");
    expect(source).toContain("'demoData' -> 'clientIds'");
    expect(source).toContain("'demoData' -> 'appointmentIds'");
  });

  it("formats reminders with the formatter staff sends use", () => {
    // Same idempotency key, same message: a sweep resend of a staff email
    // must be byte-identical or the provider rejects it.
    expect(source).toContain("appointmentReminderEmailFields({");
    expect(source).toContain("appointmentReminderMessageFields({");
    expect(source).toContain("timeZone: appt.practiceTimezone");
    expect(source).not.toContain("toLocaleTimeString");
    expect(source).not.toContain("toLocaleDateString");
  });

  it("never auto-reclaims failed or pending reminder claims", () => {
    expect(source).toContain("claimAppointmentReminderCommunication");
    expect(source).not.toContain("REMINDER_PENDING_RECLAIM_MS");
    expect(source).not.toContain("delete(communications)");
  });
});
