import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

describe("dashboard onboarding UI states", () => {
  const activationSource = readFileSync(
    "components/dashboard/activation-checklist.tsx",
    "utf8",
  );
  const tourProviderSource = readFileSync(
    "components/tour/tour-provider.tsx",
    "utf8",
  );
  const journeyProviderSource = readFileSync(
    "components/onboarding/journey-overlay.tsx",
    "utf8",
  );
  const journeyPlanSource = readFileSync(
    "lib/onboarding/journey-plan.ts",
    "utf8",
  );
  const migrationHelpSource = readFileSync(
    "components/onboarding/migration-help-request.tsx",
    "utf8",
  );
  const settingsRouter = readFileSync("server/routers/settings.ts", "utf8");

  it("surfaces activation checklist query failures before hiding for missing data", () => {
    expect(activationSource).toContain("function ActivationChecklistError");
    expect(activationSource).toContain("function ActivationChecklistLoading");
    expect(activationSource).toContain("const loadError =");
    expect(activationSource).toContain("Setup checklist could not load");
    expect(activationSource).toContain("const isChecklistLoading");
    expect(activationSource).toContain("practice.isLoading");
    expect(activationSource).toContain(
      "if (isChecklistLoading) return <ActivationChecklistLoading />",
    );
    expect(activationSource).toContain("!clientPayments.data");
    expect(activationSource).toContain(
      "Setup checklist data was unavailable. Try loading it again.",
    );
    expect(activationSource).toContain("state.refetch()");
    expect(activationSource).toContain("onboarding.refetch()");
    expect(activationSource).toContain("practice.refetch()");
    expect(activationSource).toContain("sub.refetch()");
    expect(activationSource.indexOf("if (loadError)")).toBeLessThan(
      activationSource.indexOf("if (isChecklistLoading)"),
    );
    expect(activationSource.indexOf("if (isChecklistLoading)")).toBeLessThan(
      activationSource.indexOf("!clientPayments.data"),
    );
    expect(activationSource.indexOf("!clientPayments.data")).toBeLessThan(
      activationSource.indexOf("const practiceData = practice.data"),
    );
    expect(activationSource).toContain("const checklistState = state.data");
    expect(activationSource).toContain(
      "const onboardingData = onboarding.data",
    );
    expect(activationSource).toContain("const practiceData = practice.data");
    expect(activationSource).toContain("const subscriptionData = sub.data");
    expect(activationSource).toContain(
      'const practiceName = practiceData.name ?? "your practice"',
    );
    expect(activationSource).toContain(
      "done: !!practiceData.logoUrl || !!brandColor",
    );
    expect(activationSource).toContain("done: onboardingData.hasRealData");
    expect(activationSource).toContain(
      'label: "Configure appointment requests"',
    );
    expect(activationSource).toContain(
      "bookingData.page?.published === true &&",
    );
    expect(activationSource).toContain(
      "bookingData.page.config.bookableTypeIds.length > 0",
    );
    expect(activationSource).toContain('label: "Finish texting activation"');
    expect(activationSource).toContain("done: textingData.hasActiveNumber");
    expect(activationSource).toContain(
      "textingData.setupAvailable || textingData.hasAnyNumber",
    );
    expect(activationSource.indexOf("includeTextingMilestone")).toBeLessThan(
      activationSource.indexOf('key: "texting"'),
    );
    expect(activationSource).toContain('label: "Add one real client and pet"');
    expect(activationSource).toContain('href: "/clients/new"');
    expect(activationSource).toContain(
      'label: "Book that pet\'s first appointment"',
    );
    expect(activationSource).toContain(
      "done: onboardingData.hasRealAppointment",
    );
    expect(activationSource).toContain('label: "Complete your first visit"');
    expect(activationSource).toContain(
      "done: onboardingData.hasCompletedRealVisit",
    );
    expect(activationSource).toContain(
      "`/encounters/${onboardingData.nextRealAppointmentId}`",
    );
    expect(activationSource).toContain(': "/schedule"');
    expect(activationSource.indexOf('key: "firstAppointment"')).toBeLessThan(
      activationSource.indexOf('key: "firstVisit"'),
    );
    expect(activationSource).toContain('label: "Set up client card payments"');
    expect(activationSource).toContain("done: clientPaymentData.enabled");
    expect(activationSource).toContain('pathway.value === "explore"');
    expect(activationSource).not.toContain("practice.data?.");
    expect(activationSource).not.toContain("sub.data.");
    expect(activationSource).not.toContain("onboarding.data.hasDemoData");
  });

  it("retired the dormant welcome panel in favor of the welcome surface", () => {
    // The old ?welcome=1 panel is gone; the dashboard leads with the
    // activation checklist, and greeting lives in components/welcome/.
    const dashboardSource = readFileSync("app/(dashboard)/page.tsx", "utf8");
    expect(dashboardSource).not.toContain("WelcomePanel");
    expect(dashboardSource).toContain("<ActivationChecklist />");
  });

  it("keeps tour setup persistence admin-only at the provider boundary", () => {
    expect(tourProviderSource).toContain(
      'import { useSession } from "next-auth/react"',
    );
    expect(tourProviderSource).toContain(
      'status === "authenticated" && session?.user?.role === "admin"',
    );
    expect(tourProviderSource).toContain("enabled: isAdmin");
    expect(tourProviderSource).toContain("if (!isAdmin) return;");
    expect(tourProviderSource).toContain(
      "migrationSource: prev?.migrationSource ?? null",
    );
    expect(tourProviderSource).toContain(
      "prev?.migrationSourceHasCommittedChanges ?? false",
    );
    expect(tourProviderSource).toContain(
      "migrationCompletedModes: prev?.migrationCompletedModes ?? []",
    );
    expect(tourProviderSource).toContain(
      "setTourStatus.mutate({ status, lastStepId: stepId ?? null })",
    );
    expect(settingsRouter).toContain("setTourStatus: adminProcedure");
  });

  it("keeps guided setup overlay mutations admin-only at the provider boundary", () => {
    expect(journeyProviderSource).toContain(
      'import { useSession } from "next-auth/react"',
    );
    expect(journeyProviderSource).toContain(
      'status === "authenticated" && session?.user?.role === "admin"',
    );
    expect(journeyProviderSource).toContain(
      "const openJourney = useCallback(() => {",
    );
    expect(journeyProviderSource).toContain("if (!isAdmin) return;");
    expect(journeyProviderSource).toContain(
      "const isOpen = isAdmin && index !== null",
    );
    expect(journeyProviderSource).toContain("value={{ openJourney, isOpen }}");
    expect(journeyProviderSource).toContain("steps={steps}");
    expect(journeyProviderSource).toContain(
      "disabled={busy || continueDisabled}",
    );
    expect(journeyProviderSource).toContain(
      "trpc.settings.completeOnboarding.useMutation",
    );
    expect(journeyProviderSource).toContain(
      "trpc.settings.clearDemoData.useMutation",
    );
    expect(settingsRouter).toContain(
      "completeOnboarding: adminProcedure.mutation",
    );
    expect(settingsRouter).toContain("clearDemoData: adminProcedure.mutation");
    expect(settingsRouter).toContain("setOnboardingIntent: adminProcedure");
    expect(journeyPlanSource).toContain(
      '{ id: "data", title: "Bring your history with confidence." }',
    );
    expect(journeyProviderSource).toContain(
      "router.push(\n      finishPath ??\n        (state.hasImportedData",
    );
    // A preview clinic's last step routes to the card that starts its trial.
    expect(journeyProviderSource).toContain(
      "await finish(handleRef.current?.finishPath);",
    );
    expect(journeyProviderSource).toContain('"/clients/new?setup=first-visit"');
    expect(journeyProviderSource).not.toContain("<SetUpTextingStep");
    expect(journeyProviderSource).not.toContain("<AddACardStep");
    expect(journeyProviderSource).toContain(
      "FUNNEL_EVENTS.onboardingStepViewed",
    );
    expect(journeyProviderSource).toContain(
      "FUNNEL_EVENTS.onboardingStepCompleted",
    );
    expect(journeyProviderSource).toContain(
      "FUNNEL_EVENTS.onboardingCompleted",
    );
    expect(journeyProviderSource).toContain(
      "FUNNEL_EVENTS.firstActionSelected",
    );
  });

  it("uses the selected pathway to put a tailored first win first", () => {
    expect(activationSource).toContain("getOnboardingIntentOption");
    expect(activationSource).toContain("pathway.firstWinTarget");
    expect(activationSource).toContain("label: pathway.firstWin");
    expect(activationSource).toContain("hint: pathway.firstWinHint");
    expect(activationSource).toContain("{pathway.shortLabel} · {doneCount}");
  });

  it("turns the activation checklist into a mobile first-win path with a persisted help request", () => {
    expect(activationSource).toContain(
      "trpc.settings.requestOnboardingHelp.useMutation",
    );
    expect(activationSource).toContain("Help me set this up");
    expect(activationSource).toContain("Setup help requested");
    expect(activationSource).toContain("setupHelpRequestedAt");
    expect(activationSource).toContain(
      "relative z-20 w-full sm:fixed sm:bottom-4",
    );
    expect(activationSource).not.toContain(
      "fixed bottom-4 right-4 z-[70] hidden",
    );
    expect(settingsRouter).toContain(
      "requestOnboardingHelp: adminProcedure.mutation",
    );
    expect(settingsRouter).toContain('"Hands-on onboarding requested"');
    expect(activationSource).toContain("useOnboardingJourney");
    expect(activationSource).toContain("Resume guided setup");
    expect(activationSource).toContain("Start guided setup");
    expect(activationSource).toContain("onClick={openJourney}");
    expect(migrationHelpSource).toContain(
      "trpc.settings.requestMigrationHelp.useMutation",
    );
    expect(migrationHelpSource).toContain(
      "Do not email patient files or use an Anyone-with-the-link folder.",
    );
    expect(settingsRouter).toContain("requestMigrationHelp: adminProcedure");
    expect(settingsRouter).toContain('"Private migration review requested"');
  });

  it("auto-opens the wizard for unfinished, non-dismissed onboarding and resumes durably", () => {
    // Auto-open gate: only when onboarding is not finished and not dismissed.
    expect(journeyProviderSource).toContain(
      "onboardingStatus.data.completedAt == null",
    );
    expect(journeyProviderSource).toContain(
      "onboardingState.data.journeyDismissed === true",
    );
    expect(journeyProviderSource).toContain(
      "if (notFinished && !dismissed && !established)",
    );
    // Established practices (seeded demo, self-host upgrades) are never
    // greeted like new signups even without a recorded completion date.
    expect(journeyProviderSource).toContain(
      "onboardingStatus.data.establishedPractice === true",
    );
    expect(settingsRouter).toContain("ESTABLISHED_PRACTICE_PATIENT_THRESHOLD");
    expect(settingsRouter).toContain(
      "eq(visitCloseouts.practiceId, ctx.practiceId)",
    );
    expect(settingsRouter).toContain('eq(visitCloseouts.status, "completed")');
    expect(settingsRouter).toContain("isNull(visitCloseouts.deletedAt)");
    expect(settingsRouter).toContain(
      "eq(appointments.practiceId, ctx.practiceId)",
    );
    expect(settingsRouter).toContain("realAppointmentFilter");
    expect(settingsRouter).toContain("when 'in_exam' then 0");
    expect(settingsRouter).toContain("asc(appointments.startTime)");
    expect(settingsRouter).toContain("asc(appointments.id)");
    // Resume from the durable cursor rather than always step 0.
    expect(journeyProviderSource).toContain("onboardingJourneyResumeIndex({");
    expect(journeyPlanSource).toContain("retiredStepIds.has");
    expect(journeyProviderSource).toContain("setIndex(resumeIndex)");
    // "I'll finish later" records dismissal WITHOUT completing onboarding.
    expect(journeyProviderSource).toContain(
      "await persistCursor(step.id, true)",
    );
    expect(journeyProviderSource).toContain(
      "await setJourneyProgress.mutateAsync({ stepId, dismissed })",
    );
    expect(journeyProviderSource).toContain(
      "await persistCursor(steps[next]!.id, false)",
    );
    expect(journeyProviderSource).toContain(
      "await persistCursor(steps[prev]!.id, false)",
    );
    expect(journeyProviderSource).toContain(
      "if (!onboardingState.data) return;",
    );
    expect(settingsRouter).toContain("setJourneyProgress: adminProcedure");
  });
});
