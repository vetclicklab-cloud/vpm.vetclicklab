import { existsSync, readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";
import {
  assertSnapshotlessMigrationPostconditions,
  selectBaselineSnapshot,
  snapshotlessMigrationPostconditions,
  type JournalEntry,
} from "../../../../packages/db/baseline";

const repoRoot = resolve(process.cwd(), "../..");

function readRepoFile(path: string): string {
  return readFileSync(resolve(repoRoot, path), "utf8");
}

describe("committed Drizzle migrations", () => {
  it("expands consent credentials to digests without invalidating live legacy links", () => {
    const migration = readRepoFile(
      "packages/db/drizzle/0102_curved_guardian.sql",
    );
    expect(migration).toContain("SET LOCAL lock_timeout = '5s'");
    expect(migration).toContain('ALTER COLUMN "token" DROP NOT NULL');
    expect(migration).toContain('ADD COLUMN "token_hash" varchar(64)');
    expect(migration).toContain("consent_requests_token_hash_uq");
    expect(migration).toContain("consent_requests_credential_storage_check");
    expect(migration).toContain("consent_requests_token_hash_format_check");
    expect(migration).toContain('ADD COLUMN "document_render_version"');
    expect(migration).toContain('ADD COLUMN "storage_lease_token" uuid');
    expect(migration).toContain(
      "consent_requests_document_render_version_check",
    );
    expect(migration).toContain("consent_requests_evidence_guard");
    expect(migration).toContain(
      "resolve_consent_document_render_version",
    );
    expect(migration).toContain("p_original_file_id IS NULL");
    expect(migration).toContain(
      "p_original_attestation_version = 'owner-authority-v1'",
    );
    expect(migration).toContain("THEN 'consent-pdf-v2'");
    expect(migration).toContain(
      "WHEN p_original_attestation_version IS NULL THEN 'consent-pdf-v1'",
    );
  });

  it("adds bounded, digest-only signed-copy capabilities and signature methods", () => {
    const migration = readRepoFile(
      "packages/db/drizzle/0102_curved_guardian.sql",
    );
    expect(migration).toContain('CREATE TABLE "consent_receipt_capabilities"');
    expect(migration).toContain("consent_receipt_capabilities_token_hash_uq");
    expect(migration).toContain(
      "consent_receipt_capabilities_consent_tenant_fk",
    );
    expect(migration).toContain("consent_receipt_capabilities_file_tenant_fk");
    expect(migration).toContain("interval '15 minutes'");
    expect(migration).toContain('max_claims" between 1 and 3');
    expect(migration).toContain(
      "Consent receipt claims must advance atomically",
    );
    expect(migration).toContain(
      "Consent receipt capability requires an exact signed file",
    );
    expect(migration).toContain("BEFORE INSERT OR UPDATE OR DELETE");
    expect(migration).toContain('ADD COLUMN "signature_method"');
    expect(migration).toContain("consent_requests_evidence_guard");
    expect(migration).toContain(
      "CREATE OR REPLACE FUNCTION public.validate_signed_consent_file_binding()",
    );
    expect(migration).toContain("DEFERRABLE INITIALLY DEFERRED");
    expect(migration).toContain("transition_signed_consent_file_storage");
    const rls = readRepoFile("packages/db/rls/enable-rls.sql");
    expect(rls).toContain("'consent_receipt_capabilities'");
    expect(rls).toContain(
      "REVOKE ALL ON consent_receipt_capabilities FROM PUBLIC",
    );
    expect(rls).toContain(
      "GRANT SELECT, INSERT, UPDATE ON consent_receipt_capabilities TO openpims_app",
    );
    expect(rls).toContain(
      "REVOKE ALL ON FUNCTION public.protect_consent_receipt_capability()",
    );
  });

  it("moves reserved renderer repair and sealed consent restore behind the database owner", () => {
    const migration = readRepoFile(
      "packages/db/drizzle/0103_broad_cardiac.sql",
    );
    const rls = readRepoFile("packages/db/rls/enable-rls.sql");

    expect(migration).toContain(
      "CREATE OR REPLACE FUNCTION public.resolve_unreserved_consent_document_render_version",
    );
    expect(migration).toContain("AND consent.file_id IS NULL");
    expect(migration).toContain("session_user <> owner_name");
    expect(migration).toContain(
      "CREATE OR REPLACE FUNCTION public.restore_signed_consent_evidence",
    );
    expect(migration).toContain("practice.recovery_hold = true");
    expect(migration).toContain("SET search_path = ''");
    expect(migration).toContain(
      "Signed consent evidence conflicts with an existing record",
    );
    expect(migration).toContain("attested-signature-v1");
    expect(migration).toContain("legacy-pre-attestation-v1");
    expect(migration).toContain(
      "Legacy signed consent backup has invalid evidence provenance",
    );
    expect(rls).toContain(
      "REVOKE ALL ON FUNCTION public.resolve_consent_document_render_version",
    );
    expect(rls).toContain(
      "GRANT EXECUTE ON FUNCTION public.resolve_unreserved_consent_document_render_version",
    );
    expect(rls).toContain(
      "REVOKE ALL ON FUNCTION public.restore_signed_consent_evidence",
    );
  });

  it("exercises committed migrations in the CI RLS isolation job", () => {
    const ci = readRepoFile(".github/workflows/ci.yml");
    const migrationIntegrityJob = ci.slice(
      ci.indexOf("  migration-integrity:"),
      ci.indexOf("\n  rls:"),
    );

    expect(ci).toContain("pnpm --filter @openpims/db db:migrate");
    expect(ci).not.toContain("drizzle-kit push --force");
    expect(ci).toContain(
      "lib/__tests__/baseline-postconditions.integration.test.ts",
    );
    expect(ci).toContain('BASELINE_POSTCONDITION_DB_INTEGRATION: "1"');
    expect(ci).toContain("pnpm --filter @openpims/db db:consent-evidence:test");
    expect(migrationIntegrityJob).toContain("timeout-minutes: 15");
    expect(migrationIntegrityJob).toContain("persist-credentials: false");
    expect(migrationIntegrityJob).toContain(
      "MIGRATION_INTEGRITY_EVENT_NAME: ${{ github.event_name }}",
    );
    expect(migrationIntegrityJob).toContain(
      "MIGRATION_INTEGRITY_PR_BASE_SHA: ${{ github.event.pull_request.base.sha }}",
    );
    expect(migrationIntegrityJob).toContain(
      "MIGRATION_INTEGRITY_PUSH_BEFORE_SHA: ${{ github.event.before }}",
    );
    expect(migrationIntegrityJob).not.toContain("github.sha");
    expect(migrationIntegrityJob).not.toContain(
      "MIGRATION_INTEGRITY_BASE_REF:",
    );
  });

  it("includes a baseline migration registered in the Drizzle journal", () => {
    const journal = JSON.parse(
      readRepoFile("packages/db/drizzle/meta/_journal.json"),
    ) as { entries?: Array<{ tag?: string }> };

    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0000_baseline",
    );
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0001_wellness_enrollment_indexes",
    );
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0002_location_messaging_sender_index",
    );
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0003_product_inventory_indexes",
    );
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0004_auth_expiry_indexes",
    );
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0005_rate_limit_bucket_reset_index",
    );
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0006_practice_billing_indexes",
    );
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0007_patient_chart_indexes",
    );
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0008_payment_invoice_index",
    );
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0009_scheduling_configuration_indexes",
    );
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0010_webhook_dispatch_index",
    );
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0011_catalog_lookup_indexes",
    );
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0012_wellness_plan_list_index",
    );
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0013_api_key_practice_index",
    );
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0014_clinical_child_indexes",
    );
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0015_waitlist_target_indexes",
    );
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0016_appointment_target_indexes",
    );
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0017_location_guard_indexes",
    );
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0018_invoice_item_active_index",
    );
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0019_invoice_list_index",
    );
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0020_invoice_target_indexes",
    );
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0021_communications_active_indexes",
    );
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0022_email_suppressions",
    );
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0025_practice_payment_accounts",
    );
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0066_reflective_lord_tyger",
    );
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0067_wooden_orphan",
    );
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0068_flashy_thunderball",
    );
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0069_shocking_spitfire",
    );
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0077_gifted_wolverine",
    );
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0078_optimal_bloodaxe",
    );
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0079_green_shiva",
    );
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0080_unusual_bruce_banner",
    );
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0081_validate_file_recovery_constraints",
    );
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0082_overconfident_manta",
    );
    expect(
      journal.entries?.some((entry) => entry.tag?.startsWith("0084_")),
    ).toBe(true);
  });

  it("adds the durable provider SMS inbox as a system-only immutable ledger", () => {
    const journal = JSON.parse(
      readRepoFile("packages/db/drizzle/meta/_journal.json"),
    ) as { entries: Array<{ tag: string }> };
    const tag = journal.entries.find((entry) =>
      entry.tag.startsWith("0084_"),
    )?.tag;
    expect(tag).toBeTruthy();
    const migration = readRepoFile(`packages/db/drizzle/${tag}.sql`);

    for (const table of [
      "sms_provider_events",
      "sms_provider_event_conflicts",
      "sms_provider_event_conflict_reviews",
    ]) {
      expect(migration).toContain(`CREATE TABLE "${table}"`);
      expect(migration).toContain(
        `ALTER TABLE ${table} ENABLE ROW LEVEL SECURITY`,
      );
      expect(migration).toContain(`CREATE POLICY system_only ON ${table}`);
    }
    for (const object of [
      "sms_provider_events_provider_event_key_uq",
      "sms_provider_events_due_idx",
      "sms_provider_events_consent_order_idx",
      "sms_provider_events_location_tenant_fk",
      "sms_provider_events_kind_shape_check",
      "sms_provider_events_state_shape_check",
      "sms_provider_event_conflicts_identity_uq",
      "sms_provider_event_conflict_reviews_conflict_uq",
      "sms_provider_event_conflict_reviews_operation_uq",
      "sms_provider_events_mutation_guard",
      "sms_provider_event_conflicts_immutable",
      "sms_provider_event_conflict_reviews_immutable",
    ]) {
      expect(migration).toContain(object);
    }
    expect(migration).toContain(
      "GRANT SELECT, INSERT, UPDATE ON sms_provider_events TO openpims_app",
    );
    expect(migration).toContain(
      "GRANT SELECT, INSERT ON sms_provider_event_conflicts, sms_provider_event_conflict_reviews TO openpims_app",
    );
    expect(migration).toContain("raw_body_fingerprint_sha256");
    expect(migration).not.toContain("raw_payload");
    expect(migration).not.toContain("payload_json");
    expect(migration).not.toContain("processing_lease");
    expect(migration).not.toContain(
      "sms_provider_events_location_id_locations_id_fk",
    );
    expect(migration).toContain(
      '"sms_provider_events"."a2p_observed_status" is not null',
    );
    expect(migration).toContain(
      "SMS provider event attempt time must advance with its attempt count.",
    );
    expect(migration).toContain(
      "BEFORE INSERT OR UPDATE OR DELETE ON sms_provider_events",
    );
    expect(migration).toContain(
      "New SMS provider events must enter the pending state.",
    );
    expect(migration).toContain(
      '"next_attempt_at" timestamp with time zone DEFAULT clock_timestamp(),',
    );

    const rls = readRepoFile("packages/db/rls/enable-rls.sql");
    expect(rls).toContain("CREATE POLICY system_only ON sms_provider_events");
    expect(rls).toContain(
      "CREATE POLICY system_only ON sms_provider_event_conflicts",
    );
    expect(rls).toContain(
      "CREATE POLICY system_only ON sms_provider_event_conflict_reviews",
    );
    expect(rls).toContain(
      "GRANT SELECT, INSERT, UPDATE ON sms_provider_events TO openpims_app",
    );
    expect(rls).not.toContain(
      "GRANT SELECT, INSERT, UPDATE, DELETE ON sms_provider_events TO openpims_app",
    );

    const reset = readRepoFile("packages/db/reset.ts");
    expect(reset.indexOf('"sms_provider_event_conflict_reviews"')).toBeLessThan(
      reset.indexOf('"sms_provider_event_conflicts"'),
    );
    expect(reset.indexOf('"sms_provider_event_conflicts"')).toBeLessThan(
      reset.indexOf('"sms_provider_events"'),
    );
  });

  it("revokes legacy portal credentials before enforcing one-time session state", () => {
    const journal = JSON.parse(
      readRepoFile("packages/db/drizzle/meta/_journal.json"),
    ) as { entries: Array<{ tag: string }> };
    const tag = journal.entries.find((entry) =>
      entry.tag.startsWith("0097_"),
    )?.tag;
    expect(tag).toBeTruthy();

    const migration = readRepoFile(`packages/db/drizzle/${tag}.sql`);
    const revokeLegacyToken = migration.indexOf(
      'UPDATE "clients"\nSET "access_token" = NULL',
    );
    const addStateConstraint = migration.indexOf(
      'ADD CONSTRAINT "clients_portal_access_token_state_check"',
    );
    const validateStateConstraint = migration.indexOf(
      'VALIDATE CONSTRAINT "clients_portal_access_token_state_check"',
    );

    expect(migration).toContain("SET LOCAL lock_timeout = '5s'");
    expect(revokeLegacyToken).toBeGreaterThanOrEqual(0);
    expect(addStateConstraint).toBeGreaterThan(revokeLegacyToken);
    expect(migration).toContain("NOT VALID");
    expect(validateStateConstraint).toBeGreaterThan(addStateConstraint);
    expect(migration).toContain('CREATE TABLE "portal_sessions"');
    expect(migration).toContain('"portal_sessions_client_tenant_fk"');
  });

  it("stages the zero-dollar closeout constraint change with bounded locks", () => {
    const journal = JSON.parse(
      readRepoFile("packages/db/drizzle/meta/_journal.json"),
    ) as { entries: Array<{ tag: string }> };
    const tag = journal.entries.find((entry) =>
      entry.tag.startsWith("0098_"),
    )?.tag;
    expect(tag).toBeTruthy();

    const migration = readRepoFile(`packages/db/drizzle/${tag}.sql`);
    expect(migration).toContain("SET LOCAL lock_timeout = '5s'");
    expect(migration).toContain("SET LOCAL statement_timeout = '5min'");
    expect(migration).toContain(
      'ADD CONSTRAINT "visit_closeouts_completed_state_check"',
    );
    expect(migration).toContain("NOT VALID");
    expect(migration).toContain(
      'VALIDATE CONSTRAINT "visit_closeouts_completed_state_check"',
    );
  });

  it("restricts SOAP addendum restoration to the application role", () => {
    const signature =
      "public.restore_soap_note_addendum(uuid,timestamptz,uuid,uuid,uuid,text,text,uuid,text)";
    const migration = readRepoFile(
      "packages/db/drizzle/0102_curved_guardian.sql",
    );
    const rls = readRepoFile("packages/db/rls/enable-rls.sql");

    for (const source of [migration, rls]) {
      expect(source).toContain(
        `REVOKE ALL ON FUNCTION ${signature} FROM PUBLIC`,
      );
      expect(source).toContain(`REVOKE ALL ON FUNCTION ${signature} FROM anon`);
      expect(source).toContain(
        `REVOKE ALL ON FUNCTION ${signature} FROM authenticated`,
      );
      expect(source).toContain(
        `GRANT EXECUTE ON FUNCTION ${signature} TO openpims_app`,
      );
    }
  });

  it("stages file recovery constraints behind a count-only preflight", () => {
    const preflight = readRepoFile(
      "packages/db/preflight/0077_file_recovery.sql",
    );
    const migration77 = readRepoFile(
      "packages/db/drizzle/0077_gifted_wolverine.sql",
    );
    const migration78 = readRepoFile(
      "packages/db/drizzle/0078_optimal_bloodaxe.sql",
    );
    const migration79 = readRepoFile(
      "packages/db/drizzle/0079_green_shiva.sql",
    );
    const migration80 = readRepoFile(
      "packages/db/drizzle/0080_unusual_bruce_banner.sql",
    );

    for (const issue of [
      "duplicate_file_key_groups",
      "duplicate_idempotency_groups",
      "cross_tenant_uploaders",
      "available_files_without_evidence",
      "patient_id_backfills",
      "unrepairable_patient_entities",
      "appointment_patient_id_backfills",
      "unrepairable_appointment_links",
      "invalid_primary_namespaces",
      "available_replicas_without_evidence",
      "invalid_independent_replica_keys",
      "cross_tenant_capture_patients",
      "cross_tenant_capture_creators",
      "invalid_capture_appointments",
      "cross_tenant_consent_patients",
      "cross_tenant_consent_creators",
      "invalid_consent_appointments",
      "cross_tenant_consent_forms",
      "cross_tenant_consent_files",
      "invalid_consent_signing_state",
    ]) {
      expect(preflight).toContain(`'${issue}'`);
    }
    expect(preflight).not.toContain("select *");
    expect(preflight).toContain("Every release-blocking count must be zero");
    expect(preflight).toContain(
      "f.patient_id is not null and f.patient_id <> f.entity_id",
    );
    expect(migration77).toContain("duplicate practice/file keys exist");
    expect(migration77).toContain("SET LOCAL lock_timeout = '5s'");
    expect(migration77).toContain('"files_uploader_tenant_fk"');
    expect(migration77).toContain("NOT VALID");
    expect(migration78).toContain('"files_primary_namespace_check"');
    expect(migration78).toContain('"entity_id" is not null');
    expect(migration78).toContain("NOT VALID");
    expect(migration79).toContain(
      '"file_object_replicas_independent_object_key_check"',
    );
    expect(migration79).toContain('"object_version_id" is not null');
    expect(migration79).toContain("NOT VALID");
    expect(migration80).toContain("SET LOCAL lock_timeout = '5s'");
    expect(migration80.indexOf("consent_forms_practice_id_uq")).toBeLessThan(
      migration80.indexOf("consent_requests_form_tenant_fk"),
    );
    for (const constraint of [
      "capture_sessions_patient_tenant_fk",
      "capture_sessions_creator_tenant_fk",
      "capture_sessions_appointment_patient_tenant_fk",
      "consent_requests_patient_tenant_fk",
      "consent_requests_creator_tenant_fk",
      "consent_requests_appointment_patient_tenant_fk",
      "consent_requests_form_tenant_fk",
      "consent_requests_file_tenant_fk",
      "consent_requests_status_check",
      "consent_requests_signing_evidence_check",
    ]) {
      expect(migration80).toContain(`"${constraint}"`);
    }
    expect(migration80.match(/NOT VALID/g)).toHaveLength(10);
    expect(
      `${migration77}${migration78}${migration79}${migration80}`,
    ).not.toContain("VALIDATE CONSTRAINT");
  });

  it("keeps replica state system-only and storage events append-only", () => {
    const rls = readRepoFile("packages/db/rls/enable-rls.sql");

    expect(rls).toContain("REVOKE ALL ON file_object_replicas FROM PUBLIC");
    expect(rls).toContain(
      "GRANT SELECT, INSERT, UPDATE, DELETE ON file_object_replicas TO openpims_app",
    );
    expect(rls).toContain("REVOKE ALL ON file_storage_events FROM PUBLIC");
    expect(rls).toContain(
      "GRANT SELECT, INSERT ON file_storage_events TO openpims_app",
    );
    expect(rls).not.toContain(
      "GRANT SELECT, INSERT, UPDATE ON file_storage_events",
    );
  });

  it("validates staged recovery constraints only behind a second zero-count gate", () => {
    const preflight = readRepoFile(
      "packages/db/preflight/0081_validate_file_recovery.sql",
    );
    const validation = readRepoFile(
      "packages/db/drizzle/0081_validate_file_recovery_constraints.sql",
    );

    expect(preflight).toContain("Every count must be zero");
    for (const issue of [
      "appointments_without_patients",
      "negative_replica_attempt_counts",
      "incoherent_replica_leases",
      "negative_storage_event_sizes",
      "invalid_consent_signing_state",
      "missing_staged_constraints",
      "invalid_required_indexes",
    ]) {
      expect(preflight).toContain(`'${issue}'`);
    }
    expect(preflight).not.toContain("select *");
    expect(validation).toContain("SET LOCAL lock_timeout = '5s'");
    expect(validation).toContain("SET LOCAL statement_timeout = '5min'");
    const categoryRequiredAdd = validation.indexOf(
      'ADD CONSTRAINT "files_category_required_check"',
    );
    const categoryRequiredValidation = validation.indexOf(
      'VALIDATE CONSTRAINT "files_category_required_check"',
    );
    expect(categoryRequiredAdd).toBeGreaterThanOrEqual(0);
    expect(categoryRequiredValidation).toBeGreaterThan(categoryRequiredAdd);
    expect(validation).toContain('"category" is not null');
    expect(validation.match(/VALIDATE CONSTRAINT/g)).toHaveLength(26);
    expect(validation.match(/ADD CONSTRAINT/g)).toHaveLength(1);
  });

  it("requires the validated live consent guard before the signature swap", () => {
    const preflight = readRepoFile(
      "packages/db/preflight/0083_validate_recovery_hold_consent_signature.sql",
    );

    expect(preflight).toContain(
      "'missing_or_unvalidated_live_signing_constraint'",
    );
    expect(preflight).toContain(
      "c.conname = 'consent_requests_signing_evidence_check'",
    );
    expect(preflight).toContain("c.contype = 'c'");
    expect(preflight).toContain("c.convalidated");
  });

  it("validates every staged recovery guard before the canonical consent swap", () => {
    const validation = readRepoFile(
      "packages/db/drizzle/0083_validate_recovery_hold_consent_signature.sql",
    );

    expect(validation).toContain("SET LOCAL lock_timeout = '5s'");
    expect(validation).toContain("SET LOCAL statement_timeout = '5min'");
    expect(validation.match(/VALIDATE CONSTRAINT/g)).toHaveLength(5);
    const validations = [
      "practices_recovery_hold_evidence_check",
      "consent_requests_signature_evidence_pair_check",
      "consent_requests_signature_evidence_size_check",
      "consent_requests_signature_evidence_hash_check",
      "consent_requests_signing_signature_evidence_check",
    ].map((name) => validation.indexOf(`VALIDATE CONSTRAINT "${name}"`));
    expect(validations.every((index) => index >= 0)).toBe(true);

    const dropOld = validation.indexOf(
      'DROP CONSTRAINT "consent_requests_signing_evidence_check"',
    );
    const renameStrong = validation.indexOf(
      'RENAME CONSTRAINT "consent_requests_signing_signature_evidence_check" TO "consent_requests_signing_evidence_check"',
    );
    expect(dropOld).toBeGreaterThan(Math.max(...validations));
    expect(renameStrong).toBeGreaterThan(dropOld);
  });

  it("keeps the file recovery snapshot lineage contiguous", () => {
    const snapshots = [
      "0076",
      "0077",
      "0078",
      "0079",
      "0080",
      "0081",
      "0082",
      "0083",
      "0084",
    ].map((prefix) => {
      const path = JSON.parse(
        readRepoFile("packages/db/drizzle/meta/_journal.json"),
      ).entries.find((entry: { tag: string }) =>
        entry.tag.startsWith(`${prefix}_`),
      )?.tag;
      expect(path).toBeTruthy();
      return JSON.parse(
        readRepoFile(`packages/db/drizzle/meta/${prefix}_snapshot.json`),
      ) as { id: string; prevId: string };
    });

    for (let index = 1; index < snapshots.length; index++) {
      expect(snapshots[index]!.prevId).toBe(snapshots[index - 1]!.id);
    }
  });

  it("backfills clinical provider capability before indexing it", () => {
    const sql = readRepoFile(
      "packages/db/drizzle/0066_reflective_lord_tyger.sql",
    );
    const addColumn = sql.indexOf('ADD COLUMN "is_veterinarian"');
    const backfill = sql.indexOf(
      'SET "is_veterinarian" = true WHERE "role" = \'veterinarian\'',
    );
    const index = sql.indexOf('CREATE INDEX "users_veterinarian_idx"');

    expect(addColumn).toBeGreaterThanOrEqual(0);
    expect(backfill).toBeGreaterThan(addColumn);
    expect(index).toBeGreaterThan(backfill);
  });

  it("hardens weekly provider schedules before online availability uses them", () => {
    const sql = readRepoFile("packages/db/drizzle/0067_wooden_orphan.sql");

    const preflight = sql.indexOf("staff_schedules contains a cross-tenant");
    const userTenantFk = sql.indexOf("staff_schedules_user_tenant_fk");
    const locationTenantFk = sql.indexOf("staff_schedules_location_tenant_fk");
    const activeWindowIndex = sql.indexOf("staff_schedules_active_window_uq");
    const activeNullLocationWindowIndex = sql.indexOf(
      "staff_schedules_active_null_location_window_uq",
    );
    const dayCheck = sql.indexOf("staff_schedules_day_of_week_check");
    const timeCheck = sql.indexOf("staff_schedules_time_range_check");

    expect(preflight).toBeGreaterThanOrEqual(0);
    expect(userTenantFk).toBeGreaterThan(preflight);
    expect(locationTenantFk).toBeGreaterThan(preflight);
    expect(activeWindowIndex).toBeGreaterThan(preflight);
    expect(activeNullLocationWindowIndex).toBeGreaterThan(preflight);
    expect(dayCheck).toBeGreaterThan(preflight);
    expect(timeCheck).toBeGreaterThan(preflight);
    expect(sql).toContain("duplicate active working windows");
    expect(sql).toContain("day_of_week NOT BETWEEN 0 AND 6");
    expect(sql).toContain("start_time >= end_time");
    expect(sql).toContain('"location_id" is not null');
    expect(sql).toContain('"location_id" is null');
  });

  it("expands appointments to location-aware scheduling without guessing", () => {
    const sql = readRepoFile("packages/db/drizzle/0068_flashy_thunderball.sql");

    const addColumn = sql.indexOf(
      'ALTER TABLE "appointments" ADD COLUMN "location_id" uuid',
    );
    const roomBackfill = sql.indexOf("UPDATE rooms r");
    const appointmentBackfill = sql.indexOf("UPDATE appointments a");
    const postflight = sql.indexOf("unresolved appointment location remains");
    const roomCompatibilityTrigger = sql.indexOf(
      "rooms_assign_scheduling_location",
    );
    const appointmentCompatibilityTrigger = sql.indexOf(
      "appointments_assign_scheduling_location",
    );
    const tenantFk = sql.indexOf("appointments_location_tenant_fk");
    const roomLocationFk = sql.indexOf("appointments_room_location_tenant_fk");
    const locationIndex = sql.indexOf("appointments_location_time_idx");

    expect(addColumn).toBeGreaterThanOrEqual(0);
    expect(roomBackfill).toBeGreaterThan(addColumn);
    expect(appointmentBackfill).toBeGreaterThan(roomBackfill);
    expect(postflight).toBeGreaterThan(appointmentBackfill);
    expect(roomCompatibilityTrigger).toBeGreaterThan(postflight);
    expect(appointmentCompatibilityTrigger).toBeGreaterThan(
      roomCompatibilityTrigger,
    );
    expect(tenantFk).toBeGreaterThan(postflight);
    expect(roomLocationFk).toBeGreaterThan(postflight);
    expect(locationIndex).toBeGreaterThan(roomLocationFk);
    expect(sql).toContain("a room has no unambiguous active location");
    expect(sql).toContain("appointment and room locations disagree");
    expect(sql).toContain("SELECT count(*)\n          FROM locations sole");
    expect(sql).toContain("NOT VALID");
    expect(sql).toContain("VALIDATE CONSTRAINT");
    expect(sql).toContain("SET search_path = ''");
    expect(sql).toContain(
      "A clinic location is required before creating this room.",
    );
    expect(sql).toContain(
      "Choose a clinic location before scheduling this appointment.",
    );
  });

  it("rejects invalid appointment time ranges at the database boundary", () => {
    const sql = readRepoFile("packages/db/drizzle/0069_shocking_spitfire.sql");

    const preflight = sql.indexOf("start_time >= end_time");
    const check = sql.indexOf("appointments_time_range_check");
    expect(preflight).toBeGreaterThanOrEqual(0);
    expect(check).toBeGreaterThan(preflight);
    expect(sql).toContain(
      '"appointments"."start_time" < "appointments"."end_time"',
    );
  });

  it("adds the attachment replica foundation in a fail-closed deployment order", () => {
    const journal = JSON.parse(
      readRepoFile("packages/db/drizzle/meta/_journal.json"),
    ) as { entries?: Array<{ tag?: string }> };
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0076_file_manifest_replica_foundation",
    );

    const sql = readRepoFile(
      "packages/db/drizzle/0076_file_manifest_replica_foundation.sql",
    );
    const replicaTable = sql.indexOf('CREATE TABLE "file_object_replicas"');
    const enableRls = sql.indexOf(
      'ALTER TABLE "file_object_replicas" ENABLE ROW LEVEL SECURITY',
    );
    const tenantIdentityIndex = sql.indexOf(
      'CREATE UNIQUE INDEX "files_practice_id_uq"',
    );
    const tenantIdentityFk = sql.indexOf(
      'ADD CONSTRAINT "file_object_replicas_file_tenant_fk"',
    );

    expect(replicaTable).toBeGreaterThanOrEqual(0);
    expect(enableRls).toBeGreaterThan(replicaTable);
    expect(tenantIdentityIndex).toBeGreaterThan(enableRls);
    expect(tenantIdentityFk).toBeGreaterThan(tenantIdentityIndex);
    expect(sql).toContain('ADD COLUMN "checksum_sha256" varchar(64)');
    expect(sql).toContain(
      'ADD COLUMN "storage_status" "file_storage_status" DEFAULT \'unverified\' NOT NULL',
    );
    expect(sql).toContain('ADD COLUMN "patient_id" uuid');
    expect(sql).toContain(
      'ADD CONSTRAINT "files_patient_tenant_fk" FOREIGN KEY ("practice_id","patient_id")',
    );
    expect(sql).toContain(
      'ADD CONSTRAINT "files_appointment_patient_tenant_fk" FOREIGN KEY ("practice_id","appointment_id","patient_id")',
    );

    const rls = readRepoFile("packages/db/rls/enable-rls.sql");
    const genericTenantTables = rls.slice(
      rls.indexOf("tbls text[] := array["),
      rls.indexOf("END$$;"),
    );
    const replicaPolicy = rls.slice(
      rls.indexOf("ALTER TABLE file_object_replicas ENABLE ROW LEVEL SECURITY"),
      rls.indexOf("-- Clinical correction events"),
    );
    expect(genericTenantTables).not.toContain("file_object_replicas");
    expect(replicaPolicy).toContain(
      "CREATE POLICY system_only ON file_object_replicas",
    );
    expect(replicaPolicy).toContain("USING (app_rls_bypass())");
    expect(replicaPolicy).toContain("WITH CHECK (app_rls_bypass())");
    expect(replicaPolicy).not.toContain("app_current_practice_id");
    const apiRoleRevokes = rls.slice(
      rls.indexOf("'REVOKE ALL ON auth_email_attempts"),
      rls.indexOf("FROM %I', r"),
    );
    for (const table of [
      "dispense_charge_queue",
      "file_object_replicas",
      "file_storage_events",
      "funnel_events",
    ]) {
      expect(apiRoleRevokes).toContain(table);
    }
  });

  it("keeps pre-signup leads and their email ledger system-only", () => {
    const sql = readRepoFile("packages/db/drizzle/0111_growth_leads.sql");
    expect(sql).toContain("SET LOCAL lock_timeout = '5s'");
    expect(sql).toContain('CREATE TABLE "growth_leads"');
    expect(sql).toContain('CREATE TABLE "growth_lead_emails"');
    expect(sql).toContain('"disclosure_version" varchar(32) NOT NULL');
    expect(sql).toContain(
      'CREATE UNIQUE INDEX "growth_lead_emails_dedupe_key_uq"',
    );
    expect(sql).toContain(
      'ALTER TABLE "growth_leads" ENABLE ROW LEVEL SECURITY',
    );
    expect(sql).toContain(
      'ALTER TABLE "growth_lead_emails" ENABLE ROW LEVEL SECURITY',
    );

    const rls = readRepoFile("packages/db/rls/enable-rls.sql");
    for (const table of ["growth_leads", "growth_lead_emails"]) {
      const policy = rls.slice(
        rls.indexOf(`ALTER TABLE ${table} ENABLE ROW LEVEL SECURITY`),
      );
      expect(policy).toContain(`CREATE POLICY system_only ON ${table}`);
      expect(policy.slice(0, 300)).toContain("USING (app_rls_bypass())");
      expect(policy.slice(0, 300)).not.toContain("app_current_practice_id");
    }
    const apiRoleRevokes = rls.slice(
      rls.indexOf("'REVOKE ALL ON auth_email_attempts"),
      rls.indexOf("FROM %I', r"),
    );
    expect(apiRoleRevokes).toContain("growth_leads");
    expect(apiRoleRevokes).toContain("growth_lead_emails");
  });

  it("adds durable replica leases and append-only storage evidence", () => {
    const sql = readRepoFile("packages/db/drizzle/0077_gifted_wolverine.sql");
    const eventTable = sql.indexOf('CREATE TABLE "file_storage_events"');
    const eventRls = sql.indexOf(
      'ALTER TABLE "file_storage_events" ENABLE ROW LEVEL SECURITY',
    );
    const eventTenantFk = sql.indexOf(
      'ADD CONSTRAINT "file_storage_events_file_tenant_fk"',
    );
    const patientEntityBackfill = sql.indexOf(
      'SET "patient_id" = f."entity_id"',
    );
    const appointmentBackfill = sql.indexOf(
      'SET "patient_id" = a."patient_id"',
    );
    const appointmentCheck = sql.indexOf(
      'ADD CONSTRAINT "files_appointment_requires_patient_check"',
    );

    expect(eventTable).toBeGreaterThanOrEqual(0);
    expect(eventRls).toBeGreaterThan(eventTable);
    expect(eventTenantFk).toBeGreaterThan(eventRls);
    expect(patientEntityBackfill).toBeGreaterThan(eventTenantFk);
    expect(appointmentBackfill).toBeGreaterThan(patientEntityBackfill);
    expect(appointmentCheck).toBeGreaterThan(appointmentBackfill);
    expect(sql).toContain(
      'CREATE INDEX "file_object_replicas_due_idx" ON "file_object_replicas"',
    );
    expect(sql).toContain(
      'CONSTRAINT "file_object_replicas_lease_coherence_check"',
    );
    expect(sql).toContain(
      'CONSTRAINT "file_object_replicas_available_evidence_check"',
    );
    expect(sql).toContain(
      'CREATE UNIQUE INDEX "files_practice_idempotency_key_uq"',
    );

    const rls = readRepoFile("packages/db/rls/enable-rls.sql");
    const eventPolicies = rls.slice(
      rls.indexOf("ALTER TABLE file_storage_events ENABLE ROW LEVEL SECURITY"),
      rls.indexOf("-- Clinical correction events"),
    );
    expect(eventPolicies).toContain(
      "CREATE POLICY system_read ON file_storage_events",
    );
    expect(eventPolicies).toContain(
      "CREATE POLICY system_insert ON file_storage_events",
    );
    expect(eventPolicies).not.toContain("FOR UPDATE");
    expect(eventPolicies).not.toContain("FOR DELETE");
    expect(eventPolicies).toContain(
      "REVOKE ALL ON file_storage_events FROM openpims_app",
    );
    expect(eventPolicies).toContain(
      "GRANT SELECT, INSERT ON file_storage_events TO openpims_app",
    );
  });

  it("captures hot-table indexes in the baseline SQL", () => {
    const sql = readRepoFile("packages/db/drizzle/0000_baseline.sql");

    for (const indexName of [
      "communications_practice_list_idx",
      "communications_client_timeline_idx",
      "communications_inbox_status_idx",
      "communications_assigned_idx",
      "vaccination_records_patient_idx",
      "vaccination_records_practice_due_idx",
      "lab_results_patient_idx",
      "lab_results_practice_status_idx",
      "procedures_patient_idx",
      "procedures_practice_idx",
      "soap_notes_patient_idx",
      "soap_notes_practice_idx",
      "clinical_notes_patient_idx",
      "clinical_notes_practice_idx",
      "problem_list_patient_status_idx",
      "problem_list_practice_status_idx",
      "users_practice_idx",
      "users_location_idx",
      "users_role_idx",
      "locations_practice_idx",
      "locations_primary_idx",
      "products_practice_idx",
      "products_location_idx",
      "products_sku_idx",
      "products_expiration_idx",
      "invoice_items_invoice_idx",
      "invoice_items_item_idx",
      "prescriptions_patient_status_idx",
      "prescriptions_practice_status_idx",
      "prescriptions_product_idx",
    ]) {
      expect(sql).toContain(`CREATE INDEX "${indexName}"`);
    }
  });

  it("commits wellness enrollment indexes used by billing automation", () => {
    const sql = readRepoFile(
      "packages/db/drizzle/0001_wellness_enrollment_indexes.sql",
    );

    expect(sql).toContain(
      'CREATE INDEX "wellness_enrollments_billing_due_idx"',
    );
    expect(sql).toContain('CREATE INDEX "wellness_enrollments_target_idx"');
  });

  it("commits the location messaging sender index used by SMS webhooks", () => {
    const sql = readRepoFile(
      "packages/db/drizzle/0002_location_messaging_sender_index.sql",
    );

    expect(sql).toContain('CREATE INDEX "location_messaging_sender_idx"');
    expect(sql).toContain('ON "location_messaging"');
    expect(sql).toContain('("sender_e164")');
  });

  it("commits product indexes used by inventory list and alert workflows", () => {
    const sql = readRepoFile(
      "packages/db/drizzle/0003_product_inventory_indexes.sql",
    );

    expect(sql).toContain('CREATE INDEX "products_practice_name_idx"');
    expect(sql).toContain(
      'ON "products" USING btree ("practice_id","deleted_at","name")',
    );
    expect(sql).toContain('CREATE INDEX "products_stock_alert_idx"');
    expect(sql).toContain(
      'ON "products" USING btree ("practice_id","deleted_at","stock_quantity")',
    );
  });

  it("commits auth expiry indexes used by cleanup automation", () => {
    const sql = readRepoFile(
      "packages/db/drizzle/0004_auth_expiry_indexes.sql",
    );

    expect(sql).toContain('CREATE INDEX "sessions_expires_idx"');
    expect(sql).toContain('ON "sessions" USING btree ("expires")');
    expect(sql).toContain('CREATE INDEX "verification_tokens_expires_idx"');
    expect(sql).toContain('ON "verification_tokens" USING btree ("expires")');
    expect(sql).toContain('CREATE INDEX "auth_tokens_expires_idx"');
    expect(sql).toContain('ON "auth_tokens" USING btree ("expires_at")');
  });

  it("commits the rate-limit reset index used by cleanup automation", () => {
    const sql = readRepoFile(
      "packages/db/drizzle/0005_rate_limit_bucket_reset_index.sql",
    );

    expect(sql).toContain('CREATE INDEX "rate_limit_buckets_reset_at_idx"');
    expect(sql).toContain('ON "rate_limit_buckets" USING btree ("reset_at")');
  });

  it("commits practice indexes used by hosted billing automation", () => {
    const sql = readRepoFile(
      "packages/db/drizzle/0006_practice_billing_indexes.sql",
    );

    expect(sql).toContain('CREATE INDEX "practices_billing_trial_idx"');
    expect(sql).toContain(
      'ON "practices" USING btree ("billing_status","trial_ends_at","deleted_at")',
    );
    expect(sql).toContain('CREATE INDEX "practices_stripe_customer_idx"');
    expect(sql).toContain(
      'ON "practices" USING btree ("stripe_customer_id","deleted_at")',
    );
    expect(sql).toContain('CREATE INDEX "practices_stripe_subscription_idx"');
    expect(sql).toContain(
      'ON "practices" USING btree ("stripe_subscription_id","deleted_at")',
    );
  });

  it("commits patient chart indexes used by weight and allergy lookups", () => {
    const sql = readRepoFile(
      "packages/db/drizzle/0007_patient_chart_indexes.sql",
    );

    expect(sql).toContain(
      'CREATE INDEX "patient_weights_patient_recorded_idx"',
    );
    expect(sql).toContain(
      'ON "patient_weights" USING btree ("patient_id","deleted_at","recorded_at")',
    );
    expect(sql).toContain('CREATE INDEX "patient_allergies_patient_idx"');
    expect(sql).toContain(
      'ON "patient_allergies" USING btree ("patient_id","deleted_at")',
    );
  });

  it("commits the payment invoice index used by billing history lookups", () => {
    const sql = readRepoFile(
      "packages/db/drizzle/0008_payment_invoice_index.sql",
    );

    expect(sql).toContain('CREATE INDEX "payments_invoice_idx"');
    expect(sql).toContain(
      'ON "payments" USING btree ("invoice_id","deleted_at","received_at")',
    );
  });

  it("commits Stripe Connect practice payment account storage", () => {
    const sql = readRepoFile(
      "packages/db/drizzle/0025_practice_payment_accounts.sql",
    );

    expect(sql).toContain('CREATE TABLE "practice_payment_accounts"');
    expect(sql).toContain('"stripe_account_id" varchar(128) NOT NULL');
    expect(sql).toContain(
      'CREATE UNIQUE INDEX "practice_payment_accounts_practice_provider_uq"',
    );
    expect(sql).toContain(
      'CREATE INDEX "practice_payment_accounts_status_idx"',
    );
  });

  it("commits scheduling indexes used by settings and booking lookups", () => {
    const sql = readRepoFile(
      "packages/db/drizzle/0009_scheduling_configuration_indexes.sql",
    );

    expect(sql).toContain('CREATE INDEX "appointment_types_practice_name_idx"');
    expect(sql).toContain(
      'ON "appointment_types" USING btree ("practice_id","deleted_at","name")',
    );
    expect(sql).toContain('CREATE INDEX "rooms_practice_name_idx"');
    expect(sql).toContain(
      'ON "rooms" USING btree ("practice_id","deleted_at","name")',
    );
    expect(sql).toContain('CREATE INDEX "rooms_location_idx"');
    expect(sql).toContain(
      'ON "rooms" USING btree ("practice_id","location_id","deleted_at")',
    );
    expect(sql).toContain('CREATE INDEX "staff_schedules_location_idx"');
    expect(sql).toContain(
      'ON "staff_schedules" USING btree ("practice_id","location_id","deleted_at")',
    );
    expect(sql).toContain('CREATE INDEX "staff_schedules_user_idx"');
    expect(sql).toContain(
      'ON "staff_schedules" USING btree ("practice_id","user_id","deleted_at")',
    );
  });

  it("commits the webhook dispatch index used by integration delivery", () => {
    const sql = readRepoFile(
      "packages/db/drizzle/0010_webhook_dispatch_index.sql",
    );

    expect(sql).toContain('CREATE INDEX "webhooks_practice_active_idx"');
    expect(sql).toContain(
      'ON "webhooks" USING btree ("practice_id","deleted_at","active")',
    );
  });

  it("commits catalog indexes used by service and supplier pickers", () => {
    const sql = readRepoFile(
      "packages/db/drizzle/0011_catalog_lookup_indexes.sql",
    );

    expect(sql).toContain('CREATE INDEX "services_practice_name_idx"');
    expect(sql).toContain(
      'ON "services" USING btree ("practice_id","deleted_at","name")',
    );
    expect(sql).toContain('CREATE INDEX "suppliers_practice_name_idx"');
    expect(sql).toContain(
      'ON "suppliers" USING btree ("practice_id","deleted_at","name")',
    );
  });

  it("commits the wellness plan index used by plan lists", () => {
    const sql = readRepoFile(
      "packages/db/drizzle/0012_wellness_plan_list_index.sql",
    );

    expect(sql).toContain('CREATE INDEX "wellness_plans_practice_created_idx"');
    expect(sql).toContain(
      'ON "wellness_plans" USING btree ("practice_id","deleted_at","created_at")',
    );
  });

  it("commits the API key index used by admin key lists", () => {
    const sql = readRepoFile(
      "packages/db/drizzle/0013_api_key_practice_index.sql",
    );

    expect(sql).toContain('CREATE INDEX "api_keys_practice_created_idx"');
    expect(sql).toContain(
      'ON "api_keys" USING btree ("practice_id","deleted_at","created_at")',
    );
  });

  it("commits clinical child indexes used by plan and export lookups", () => {
    const sql = readRepoFile(
      "packages/db/drizzle/0014_clinical_child_indexes.sql",
    );

    expect(sql).toContain('CREATE INDEX "case_entries_case_idx"');
    expect(sql).toContain(
      'ON "case_entries" USING btree ("case_id","deleted_at")',
    );
    expect(sql).toContain('CREATE INDEX "treatment_plan_items_plan_order_idx"');
    expect(sql).toContain(
      'ON "treatment_plan_items" USING btree ("plan_id","deleted_at","sort_order")',
    );
  });

  it("commits waitlist target indexes used by delete safety checks", () => {
    const sql = readRepoFile(
      "packages/db/drizzle/0015_waitlist_target_indexes.sql",
    );

    expect(sql).toContain('CREATE INDEX "waitlist_client_status_idx"');
    expect(sql).toContain(
      'ON "appointment_waitlist" USING btree ("practice_id","client_id","status","deleted_at")',
    );
    expect(sql).toContain('CREATE INDEX "waitlist_patient_status_idx"');
    expect(sql).toContain(
      'ON "appointment_waitlist" USING btree ("practice_id","patient_id","status","deleted_at")',
    );
  });

  it("commits appointment target indexes used by active appointment guards", () => {
    const sql = readRepoFile(
      "packages/db/drizzle/0016_appointment_target_indexes.sql",
    );

    for (const [indexName, targetColumn] of [
      ["appointments_client_status_idx", "client_id"],
      ["appointments_patient_status_idx", "patient_id"],
      ["appointments_doctor_status_idx", "doctor_id"],
      ["appointments_type_status_idx", "type_id"],
      ["appointments_room_status_idx", "room_id"],
    ]) {
      expect(sql).toContain(`CREATE INDEX "${indexName}"`);
      expect(sql).toContain(
        `ON "appointments" USING btree ("practice_id","${targetColumn}","status","deleted_at")`,
      );
    }
  });

  it("commits tenant-scoped location guard indexes for staff and products", () => {
    const sql = readRepoFile(
      "packages/db/drizzle/0017_location_guard_indexes.sql",
    );

    expect(sql).toContain('DROP INDEX "users_location_idx"');
    expect(sql).toContain('DROP INDEX "products_location_idx"');
    expect(sql).toContain('CREATE INDEX "users_location_idx"');
    expect(sql).toContain(
      'ON "users" USING btree ("practice_id","location_id","deleted_at")',
    );
    expect(sql).toContain('CREATE INDEX "products_location_idx"');
    expect(sql).toContain(
      'ON "products" USING btree ("practice_id","location_id","deleted_at")',
    );
  });

  it("commits the active invoice-item index used by billing lookups", () => {
    const sql = readRepoFile(
      "packages/db/drizzle/0018_invoice_item_active_index.sql",
    );

    expect(sql).toContain('DROP INDEX "invoice_items_item_idx"');
    expect(sql).toContain('CREATE INDEX "invoice_items_item_idx"');
    expect(sql).toContain(
      'ON "invoice_items" USING btree ("item_type","deleted_at","item_id")',
    );
  });

  it("commits the invoice list index used by newest-first billing pages", () => {
    const sql = readRepoFile("packages/db/drizzle/0019_invoice_list_index.sql");

    expect(sql).toContain('DROP INDEX "invoices_practice_idx"');
    expect(sql).toContain('CREATE INDEX "invoices_practice_idx"');
    expect(sql).toContain(
      'ON "invoices" USING btree ("practice_id","deleted_at","created_at")',
    );
  });

  it("commits invoice target indexes used by client and patient workflows", () => {
    const sql = readRepoFile(
      "packages/db/drizzle/0020_invoice_target_indexes.sql",
    );

    expect(sql).toContain('DROP INDEX "invoices_client_idx"');
    expect(sql).toContain('CREATE INDEX "invoices_client_idx"');
    expect(sql).toContain(
      'ON "invoices" USING btree ("practice_id","client_id","deleted_at","created_at")',
    );
    expect(sql).toContain('CREATE INDEX "invoices_patient_idx"');
    expect(sql).toContain(
      'ON "invoices" USING btree ("practice_id","patient_id","client_id","deleted_at")',
    );
  });

  it("commits active communications indexes used by shared inbox workflows", () => {
    const sql = readRepoFile(
      "packages/db/drizzle/0021_communications_active_indexes.sql",
    );

    for (const indexName of [
      "communications_practice_list_idx",
      "communications_client_timeline_idx",
      "communications_inbox_status_idx",
      "communications_assigned_idx",
      "communications_provider_message_idx",
    ]) {
      expect(sql).toContain(`DROP INDEX "${indexName}"`);
      expect(sql).toContain(`CREATE INDEX "${indexName}"`);
    }

    expect(sql).toContain(
      'ON "communications" USING btree ("practice_id","deleted_at","created_at")',
    );
    expect(sql).toContain(
      'ON "communications" USING btree ("practice_id","client_id","deleted_at","created_at")',
    );
    expect(sql).toContain(
      'ON "communications" USING btree ("practice_id","direction","status","deleted_at")',
    );
    expect(sql).toContain(
      'ON "communications" USING btree ("practice_id","assigned_to","deleted_at")',
    );
    expect(sql).toContain(
      'ON "communications" USING btree ("practice_id","provider_message_id","channel","direction")',
    );
  });

  it("commits email suppressions used by Resend bounce and complaint webhooks", () => {
    const sql = readRepoFile("packages/db/drizzle/0022_email_suppressions.sql");

    expect(sql).toContain('CREATE TYPE "public"."email_suppression_reason"');
    expect(sql).toContain('CREATE TABLE "email_suppressions"');
    expect(sql).toContain(
      'CREATE UNIQUE INDEX "email_suppressions_practice_email_uq"',
    );
    expect(sql).toContain(
      'ON "email_suppressions" USING btree ("practice_id","email")',
    );
    expect(sql).toContain('CREATE INDEX "email_suppressions_practice_idx"');
    expect(sql).toContain(
      'ON "email_suppressions" USING btree ("practice_id","deleted_at")',
    );
  });

  it("commits the tenant-scoped exact-file migration run ledger", () => {
    const journal = JSON.parse(
      readRepoFile("packages/db/drizzle/meta/_journal.json"),
    ) as { entries?: Array<{ tag?: string }> };
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0041_aromatic_rhino",
    );

    const sql = readRepoFile("packages/db/drizzle/0041_aromatic_rhino.sql");
    expect(sql).toContain('CREATE TABLE "migration_runs"');
    expect(sql).toContain(
      "CREATE TYPE \"public\".\"migration_run_mode\" AS ENUM('clients', 'patients', 'vaccinations', 'soap_notes')",
    );
    expect(sql).toContain("'previewed', 'superseded', 'committing'");
    expect(sql).toContain('CONSTRAINT "migration_runs_file_hash_check"');
    expect(sql).toContain('CONSTRAINT "migration_runs_counts_check"');
    expect(sql).toContain(
      'CREATE UNIQUE INDEX "migration_runs_active_preview_uq"',
    );
    expect(sql).toContain(
      'WHERE "migration_runs"."status" = \'previewed\' and "migration_runs"."deleted_at" is null',
    );

    const rls = readRepoFile("packages/db/rls/enable-rls.sql");
    expect(rls).toContain("'migration_runs'");
  });

  it("adds a backfilled privacy-safe reviewed-plan hash to migration runs", () => {
    const journal = JSON.parse(
      readRepoFile("packages/db/drizzle/meta/_journal.json"),
    ) as { entries?: Array<{ tag?: string }> };
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0044_round_chronomancer",
    );

    const sql = readRepoFile("packages/db/drizzle/0044_round_chronomancer.sql");
    expect(sql).toContain('ADD COLUMN "reviewed_plan_hash" varchar(64)');
    expect(sql).toContain(
      'SET "reviewed_plan_hash" = "file_hash" WHERE "reviewed_plan_hash" IS NULL',
    );
    expect(sql).toContain('ALTER COLUMN "reviewed_plan_hash" SET NOT NULL');
    expect(sql).toContain(
      'CONSTRAINT "migration_runs_reviewed_plan_hash_check"',
    );
    expect(sql).not.toMatch(/name|email|phone|note|external_id|raw_csv/i);
  });

  it("fails clearly before enforcing one active invoice per visit", () => {
    const journal = JSON.parse(
      readRepoFile("packages/db/drizzle/meta/_journal.json"),
    ) as { entries?: Array<{ tag?: string }> };
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0042_tough_mattie_franklin",
    );

    const sql = readRepoFile(
      "packages/db/drizzle/0042_tough_mattie_franklin.sql",
    );
    expect(sql).toContain('CREATE TABLE "visit_closeouts"');
    expect(sql).toContain('"medication_snapshot" jsonb');
    expect(sql).toContain('"follow_up_scheduled_at" timestamp with time zone');
    expect(sql).toContain('GROUP BY "practice_id", "appointment_id"');
    expect(sql).toContain("HAVING count(*) > 1");
    expect(sql).toContain(
      "duplicate active visit invoices require audited reconciliation",
    );
    expect(sql).toContain(
      'CREATE UNIQUE INDEX "invoices_active_appointment_uq"',
    );
  });

  it("adds retry-safe billing operations and accountable follow-up work", () => {
    const journal = JSON.parse(
      readRepoFile("packages/db/drizzle/meta/_journal.json"),
    ) as { entries?: Array<{ tag?: string }> };
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0043_normal_bloodstrike",
    );

    const sql = readRepoFile("packages/db/drizzle/0043_normal_bloodstrike.sql");
    expect(sql).toContain('"prescriptions" ADD COLUMN "operation_id" uuid');
    expect(sql).toContain(
      '"invoice_adjustments" ADD COLUMN "operation_key" varchar(160)',
    );
    expect(sql).toContain(
      'CONSTRAINT "invoice_items_source_prescription_id_prescriptions_id_fk"',
    );
    expect(sql).toContain(
      'CREATE UNIQUE INDEX "invoice_items_source_prescription_invoice_uq"',
    );
    expect(sql).toContain(
      'CREATE UNIQUE INDEX "prescriptions_practice_operation_uq"',
    );
    expect(sql).toContain(
      'CREATE UNIQUE INDEX "invoice_adjustments_operation_key_uq"',
    );
    expect(sql).toContain("invoice_adjustments_operation_result_check");
    expect(sql).toContain(
      'ALTER TYPE "public"."visit_follow_up_disposition" RENAME TO "visit_follow_up_disposition_old"',
    );
    expect(sql).toContain(
      "CREATE TYPE \"public\".\"visit_follow_up_disposition\" AS ENUM('none', 'needed', 'scheduled')",
    );
    expect(sql).toContain(
      'ALTER TABLE "visit_closeouts" ALTER COLUMN "follow_up_disposition" TYPE',
    );
    expect(sql).not.toContain("ADD VALUE 'needed'");
    expect(sql).toContain(
      '"visit_closeouts" ADD COLUMN "follow_up_due_date" date',
    );
    expect(sql).toContain(
      '"visit_closeouts" ADD COLUMN "amendment_draft" jsonb',
    );
    expect(sql).toContain("visit_closeouts_follow_up_resolution_check");
  });

  it("adds the tenant-bound visit work ledger before checkout enforcement ships", () => {
    const journal = JSON.parse(
      readRepoFile("packages/db/drizzle/meta/_journal.json"),
    ) as { entries?: Array<{ tag?: string }> };
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0045_visit_work_ledger",
    );

    const sql = readRepoFile("packages/db/drizzle/0045_visit_work_ledger.sql");
    expect(sql).toContain('CREATE TABLE "visit_work_items"');
    expect(sql).toContain(
      '"vaccination_records" ADD COLUMN "appointment_id" uuid',
    );
    expect(sql).toContain("visit_work_items_exactly_one_source_check");
    expect(sql).toContain("visit_work_items_resolution_check");
    expect(sql).toContain("visit_work_items_practice_appointment_fk");
    expect(sql).toContain("visit_work_items_vaccination_source_fk");
    expect(sql).toContain("visit_work_items_invoice_visit_fk");
    expect(sql).toContain("visit_work_items_invoice_item_fk");
    expect(sql).toContain("ON CONFLICT DO NOTHING");
    expect(sql).toContain("a.status IN ('checked_in', 'in_exam')");
    expect(
      sql.indexOf('CREATE UNIQUE INDEX "appointments_practice_id_uq"'),
    ).toBeLessThan(sql.indexOf("visit_work_items_practice_appointment_fk"));
  });

  it("indexes tenant appointment vital timelines", () => {
    const journal = JSON.parse(
      readRepoFile("packages/db/drizzle/meta/_journal.json"),
    ) as { entries?: Array<{ tag?: string }> };
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0046_encounter_vitals_index",
    );

    const sql = readRepoFile(
      "packages/db/drizzle/0046_encounter_vitals_index.sql",
    );
    expect(sql).toContain(
      'CREATE INDEX "vital_signs_appointment_idx" ON "vital_signs"',
    );
    expect(sql).toContain(
      '("practice_id","appointment_id","deleted_at","recorded_at")',
    );
  });

  it("adds reminder retry tracking without a full-table validation scan", () => {
    const journal = JSON.parse(
      readRepoFile("packages/db/drizzle/meta/_journal.json"),
    ) as { entries?: Array<{ idx?: number; tag?: string }> };
    const tags = journal.entries?.map((entry) => entry.tag) ?? [];
    expect(tags).toContain("0109_reminder_retry_tracking");
    expect(tags).toContain("0110_reminder_claim_fencing");
    expect(tags.indexOf("0110_reminder_claim_fencing")).toBe(
      tags.indexOf("0109_reminder_retry_tracking") + 1,
    );
    expect(
      existsSync(
        resolve(repoRoot, "packages/db/drizzle/0110_reminder_attempt_started_at.sql"),
      ),
    ).toBe(false);

    const retry = readRepoFile(
      "packages/db/drizzle/0109_reminder_retry_tracking.sql",
    );
    expect(retry).toContain("SET LOCAL lock_timeout = '5s'");
    expect(retry).toContain('ADD COLUMN "reminder_attempt" integer');
    expect(retry).toContain('ADD COLUMN "reminder_automated_attempts" integer');
    expect(retry).toContain('ADD COLUMN "reminder_outcome" varchar(32)');
    expect(retry).toMatch(
      /ADD CONSTRAINT "communications_reminder_outcome_check" CHECK \([^;]*'staff_failure', 'automated_failure', 'outcome_unknown'\)\) NOT VALID;/,
    );
    // Validating in the migration's own transaction would scan the whole
    // communications table while holding the ADD COLUMN lock.
    expect(retry).not.toContain("VALIDATE CONSTRAINT");

    const fencing = readRepoFile(
      "packages/db/drizzle/0110_reminder_claim_fencing.sql",
    );
    expect(fencing).toContain("SET LOCAL lock_timeout = '5s'");
    expect(fencing).toContain(
      'ADD COLUMN "reminder_attempt_started_at" timestamp with time zone',
    );
    expect(fencing).toContain('ADD COLUMN "reminder_claim_token" uuid');
    expect(fencing).not.toMatch(/DEFAULT|NOT NULL|VALIDATE/);
  });

  it("adds an append-only tenant-bound prescription lifecycle ledger", () => {
    const journal = JSON.parse(
      readRepoFile("packages/db/drizzle/meta/_journal.json"),
    ) as { entries?: Array<{ tag?: string }> };
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0048_prescription_lifecycle",
    );

    const sql = readRepoFile(
      "packages/db/drizzle/0048_prescription_lifecycle.sql",
    );
    const tableDefinition = sql.match(
      /CREATE TABLE "prescription_events" \([\s\S]*?\n\);/,
    )?.[0];

    expect(sql).toContain("'refill_authorized'");
    expect(tableDefinition).toBeDefined();
    expect(tableDefinition).not.toContain('"updated_at"');
    expect(tableDefinition).not.toContain('"deleted_at"');
    expect(sql).toContain("prescription_events_shape_check");
    expect(sql).toContain("prescription_events_practice_prescription_fk");
    expect(sql).toContain("prescription_events_practice_operation_uq");
    expect(sql).toContain("prescription_events_validate_source");
    expect(sql).toContain("source.patient_id = NEW.patient_id");
    expect(sql).toContain(
      "source.product_id IS NOT DISTINCT FROM NEW.product_id",
    );
    expect(sql).toContain("source.quantity IS NOT DISTINCT FROM NEW.quantity");
    expect(sql).toContain("prescription_events_immutable");
    expect(sql).toContain("app.ledger_maintenance");
    expect(sql).toContain(
      "ALTER TABLE prescription_events ENABLE ROW LEVEL SECURITY",
    );
    expect(sql).toContain(
      "GRANT SELECT, INSERT ON prescription_events TO openpims_app",
    );
    expect(sql).toContain("REVOKE ALL ON prescription_events FROM anon");
    expect(sql).toContain(
      "REVOKE ALL ON prescription_events FROM authenticated",
    );
  });

  it("adds a durable tenant-bound dispense-to-charge queue", () => {
    const journal = JSON.parse(
      readRepoFile("packages/db/drizzle/meta/_journal.json"),
    ) as { entries?: Array<{ tag?: string }> };
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0049_dispense_charge_queue",
    );

    const sql = readRepoFile(
      "packages/db/drizzle/0049_dispense_charge_queue.sql",
    );
    expect(sql).toContain('CREATE TABLE "dispense_charge_queue"');
    expect(sql).toContain('ADD COLUMN "source_dispense_charge_id" uuid');
    expect(sql).toContain("dispense_charge_queue_shape_check");
    expect(sql).toContain("dispense_charge_queue_practice_event_fk");
    expect(sql.indexOf("prescription_events_practice_id_uq")).toBeLessThan(
      sql.indexOf("dispense_charge_queue_practice_event_fk"),
    );
    expect(sql).toContain("dispense_charge_queue_validate_source");
    expect(sql).toContain("invoice_items_validate_dispense_charge");
    expect(sql).toContain("dispense_charge_queue_protect");
    expect(sql).toContain("dispense_charge_queue_no_delete");
    expect(sql).toContain("invoice_items_reopen_dispense_charge");
    expect(sql).toContain("invoices_reopen_dispense_charges");
    expect(sql).toContain("legacy_review");
    expect(sql).toContain(
      "charged prescription work does not match an active dispense invoice line",
    );
    expect(sql).toContain(
      "prescription invoice target does not match its dispense patient and visit",
    );
    expect(sql).toContain(
      "invoice.appointment_id IS DISTINCT FROM prescription.appointment_id",
    );
    expect(sql).toContain(
      "source_queue.appointment_id IS DISTINCT FROM target_invoice.appointment_id",
    );
    expect(sql).toContain("invalid medication dispense charge resolver");
    expect(sql).toContain(
      "ALTER TABLE dispense_charge_queue ENABLE ROW LEVEL SECURITY",
    );
    expect(sql).toContain(
      "GRANT SELECT, INSERT, UPDATE ON dispense_charge_queue TO openpims_app",
    );
    expect(sql).toContain("REVOKE ALL ON dispense_charge_queue FROM anon");
    expect(sql).toContain(
      "REVOKE ALL ON dispense_charge_queue FROM authenticated",
    );
  });

  it("backfills explicit requestable types for legacy booking pages", () => {
    const journal = JSON.parse(
      readRepoFile("packages/db/drizzle/meta/_journal.json"),
    ) as { entries?: Array<{ tag?: string }> };
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0052_booking_page_request_types",
    );

    const sql = readRepoFile(
      "packages/db/drizzle/0052_booking_page_request_types.sql",
    );
    expect(sql).toContain("at.practice_id = bp.practice_id");
    expect(sql).toContain("at.deleted_at IS NULL");
    expect(sql).toContain("'{bookableTypeIds}'");
    expect(sql).toContain("jsonb_array_length(legacy.active_type_ids) = 0");
    expect(sql).toContain("THEN false");
  });

  it("selects the preceding snapshot for intentional data-only baseline 0052", () => {
    const journal = JSON.parse(
      readRepoFile("packages/db/drizzle/meta/_journal.json"),
    ) as { entries: JournalEntry[] };
    const cutoff = journal.entries.findIndex(
      (entry) => entry.tag === "0052_booking_page_request_types",
    );
    const selection = selectBaselineSnapshot(
      journal.entries,
      cutoff,
      (entry) => {
        const prefix = entry.tag.split("_", 1)[0];
        return existsSync(
          resolve(repoRoot, `packages/db/drizzle/meta/${prefix}_snapshot.json`),
        );
      },
    );

    expect(selection.target.tag).toBe("0052_booking_page_request_types");
    expect(selection.snapshot.tag).toBe("0051_wide_maximus");
    expect(selection.explanation).toContain("intentional data-only migration");
    expect(selection.explanation).toContain(
      "validating schema against preceding snapshot 0051_wide_maximus",
    );
  });

  it("checks snapshotless postconditions at the exact and every later cutoff", async () => {
    const journal = JSON.parse(
      readRepoFile("packages/db/drizzle/meta/_journal.json"),
    ) as { entries: JournalEntry[] };
    const cutoff0051 = journal.entries.findIndex(
      (entry) => entry.tag === "0051_wide_maximus",
    );
    const cutoff0052 = journal.entries.findIndex(
      (entry) => entry.tag === "0052_booking_page_request_types",
    );
    const cutoff0053 = journal.entries.findIndex(
      (entry) => entry.tag === "0053_invoice_line_taxability",
    );
    const checked: string[] = [];
    const reader = async (entry: JournalEntry) => {
      checked.push(entry.tag);
      return 0;
    };

    await assertSnapshotlessMigrationPostconditions(
      journal.entries,
      cutoff0051,
      reader,
    );
    expect(checked).toEqual([]);

    await assertSnapshotlessMigrationPostconditions(
      journal.entries,
      cutoff0052,
      reader,
    );
    await assertSnapshotlessMigrationPostconditions(
      journal.entries,
      cutoff0053,
      reader,
    );
    expect(checked).toEqual([
      "0052_booking_page_request_types",
      "0052_booking_page_request_types",
    ]);
  });

  it("fails closed when a snapshotless data postcondition is violated", async () => {
    const journal = JSON.parse(
      readRepoFile("packages/db/drizzle/meta/_journal.json"),
    ) as { entries: JournalEntry[] };
    const cutoff = journal.entries.findIndex(
      (entry) => entry.tag === "0053_invoice_line_taxability",
    );

    await expect(
      assertSnapshotlessMigrationPostconditions(
        journal.entries,
        cutoff,
        async (entry, contract) => {
          expect(entry.tag).toBe("0052_booking_page_request_types");
          expect(contract).toBe(snapshotlessMigrationPostconditions[entry.tag]);
          return 1;
        },
      ),
    ).rejects.toThrow(
      "Cannot baseline through 0053_invoice_line_taxability: data-only migration 0052_booking_page_request_types has 1 active booking page row",
    );
  });

  it.each([Number.NaN, -1, 1.5, Number.MAX_SAFE_INTEGER + 1])(
    "rejects invalid snapshotless violation count %s",
    async (violations) => {
      const entries: JournalEntry[] = [
        { idx: 0, tag: "0052_booking_page_request_types", when: 1 },
      ];
      await expect(
        assertSnapshotlessMigrationPostconditions(
          entries,
          0,
          async () => violations,
        ),
      ).rejects.toThrow("returned invalid violation count");
    },
  );

  it("refuses an unapproved missing baseline snapshot with a deliberate error", () => {
    const journal = JSON.parse(
      readRepoFile("packages/db/drizzle/meta/_journal.json"),
    ) as { entries: JournalEntry[] };
    const cutoff = journal.entries.findIndex(
      (entry) => entry.tag === "0053_invoice_line_taxability",
    );

    expect(() =>
      selectBaselineSnapshot(
        journal.entries,
        cutoff,
        (entry) => entry.tag !== "0053_invoice_line_taxability",
      ),
    ).toThrow(
      "expected snapshot 0053_snapshot.json for 0053_invoice_line_taxability, but it is missing and is not an approved snapshotless migration",
    );
  });

  it("backfills immutable invoice-line and product taxability", () => {
    const journal = JSON.parse(
      readRepoFile("packages/db/drizzle/meta/_journal.json"),
    ) as { entries?: Array<{ tag?: string }> };
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0053_invoice_line_taxability",
    );

    const sql = readRepoFile(
      "packages/db/drizzle/0053_invoice_line_taxability.sql",
    );
    expect(sql).toContain(
      'ALTER TABLE "products" ADD COLUMN "taxable" boolean',
    );
    expect(sql).toContain(
      'UPDATE "products" SET "taxable" = true WHERE "taxable" IS NULL',
    );
    expect(sql).toContain(
      'ALTER TABLE "invoice_items" ADD COLUMN "taxable" boolean',
    );
    expect(sql).toContain(
      'UPDATE "invoice_items" SET "taxable" = true WHERE "taxable" IS NULL',
    );
    expect(sql.match(/ALTER COLUMN "taxable" SET NOT NULL/g)).toHaveLength(2);
  });

  it("adds an immutable tenant-scoped SMS consent evidence ledger", () => {
    const journal = JSON.parse(
      readRepoFile("packages/db/drizzle/meta/_journal.json"),
    ) as { entries?: Array<{ tag?: string }> };
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0055_flippant_silver_fox",
    );

    const sql = readRepoFile(
      "packages/db/drizzle/0055_flippant_silver_fox.sql",
    );
    expect(sql).toContain('CREATE TABLE "sms_consent_events"');
    expect(sql).toContain("sms_consent_events_client_tenant_fk");
    expect(sql).toContain("sms_consent_events_location_tenant_fk");
    expect(sql).toContain("sms_consent_events_actor_tenant_fk");
    expect(
      sql.indexOf('CREATE UNIQUE INDEX "locations_practice_id_uq"'),
    ).toBeLessThan(sql.indexOf("sms_consent_events_location_tenant_fk"));
    expect(sql).toContain("sms_consent_events_practice_event_key_uq");
    expect(sql).toContain("sms_consent_events_provider_message_uq");
    expect(sql).toContain('"provider_message_id" varchar(255)');
    expect(sql).toContain("sms_consent_events_destination_check");
    expect(sql).toContain("sms_consent_events_evidence_shape_check");
    expect(sql).toContain("sms_consent_events_actor_shape_check");
    expect(sql).toContain(
      "\"sms_consent_events\".\"provider\" in ('telnyx', 'twilio')",
    );
    expect(sql).toContain(
      'coalesce("sms_consent_events"."provider_message_id", \'\')',
    );
    expect(sql).toContain("AND c.sms_consent = true");
    expect(sql).toContain("c.sms_consent_at IS NOT NULL");
    expect(sql).toContain("split_part(c.sms_consent_source, ':', 2)");
    expect(sql).toContain("WITH consent_candidates AS MATERIALIZED");
    expect(sql).toContain("'[^0-9]'");
    expect(sql).not.toContain("'\\\\D'");
    expect(sql).toContain("normalized_destination ~ '^\\+[1-9][0-9]{7,14}$'");
    expect(sql).toContain("UPDATE clients c");
    expect(sql).toContain("AND NOT EXISTS (");
    expect(sql).not.toContain("WHERE c.sms_consent = false");
    expect(sql).toContain("sms_consent_events_immutable");
    expect(sql).toContain("app.ledger_maintenance");
    expect(sql).toContain(
      "ALTER TABLE sms_consent_events ENABLE ROW LEVEL SECURITY",
    );
    expect(sql).toContain(
      "GRANT SELECT, INSERT ON sms_consent_events TO openpims_app",
    );
    expect(sql).toContain("REVOKE ALL ON sms_consent_events FROM anon");
    expect(sql).toContain(
      "REVOKE ALL ON sms_consent_events FROM authenticated",
    );
  });

  it("adds canonical conversion projections without inventing payment dates", () => {
    const journal = JSON.parse(
      readRepoFile("packages/db/drizzle/meta/_journal.json"),
    ) as { entries?: Array<{ tag?: string }> };
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0056_lively_magdalene",
    );

    const sql = readRepoFile("packages/db/drizzle/0056_lively_magdalene.sql");
    expect(sql).toContain('CREATE TABLE "practice_conversion_milestones"');
    expect(sql).toContain("practice_conversion_milestones_payment_shape_check");
    expect(sql).toContain(
      '"practice_conversion_milestones"."amount_cents" is not null',
    );
    expect(sql).toContain(
      '"practice_conversion_milestones"."currency" is not null',
    );
    expect(sql).toContain(
      "practice_conversion_milestones_evidence_source_check",
    );
    expect(sql).toContain("stripe_events_conversion_evidence_shape_check");
    expect(sql).toContain('"stripe_events"."amount_cents" is not null');
    expect(sql).toContain('length(btrim("stripe_events"."object_id")) > 0');
    expect(sql).toContain("p.created_at");
    expect(sql).toContain("greatest(p.created_at, c.created_at, a.created_at)");
    expect(sql).toContain("p.settings -> 'demoData' -> 'clientIds'");
    expect(sql).toContain("p.settings -> 'demoData' -> 'appointmentIds'");
    expect(sql).not.toContain("FROM funnel_events");
    expect(sql).not.toContain("p.billing_status = 'active'");
    expect(sql).toContain(
      "ALTER TABLE practice_conversion_milestones ENABLE ROW LEVEL SECURITY",
    );
    expect(sql).toContain(
      "REVOKE ALL ON practice_conversion_milestones, stripe_events FROM anon",
    );
    expect(sql).toContain(
      "REVOKE ALL ON practice_conversion_milestones, stripe_events",
    );
  });

  it("allows clinics to read only their own verified conversion milestones", () => {
    const journal = JSON.parse(
      readRepoFile("packages/db/drizzle/meta/_journal.json")
    ) as { entries?: Array<{ tag?: string }> };
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0099_tenant_read_conversion_milestones"
    );

    const sql = readRepoFile(
      "packages/db/drizzle/0099_tenant_read_conversion_milestones.sql"
    );
    expect(sql).toContain(
      "CREATE POLICY tenant_select ON practice_conversion_milestones"
    );
    expect(sql).toContain("FOR SELECT");
    expect(sql).toContain(
      "OR practice_id = app_current_practice_id()"
    );
    expect(sql).toContain("FOR INSERT");
    expect(sql).toContain("FOR UPDATE");
    expect(sql).toContain("FOR DELETE");
    expect(sql).toContain("WITH CHECK (app_rls_bypass())");

    const canonicalRls = readRepoFile("packages/db/rls/enable-rls.sql");
    expect(canonicalRls).toContain(
      "CREATE POLICY tenant_select ON practice_conversion_milestones"
    );
  });

  it("creates the append-only SMS delivery ledger with valid self-FK ordering", () => {
    const journal = JSON.parse(
      readRepoFile("packages/db/drizzle/meta/_journal.json"),
    ) as { entries?: Array<{ tag?: string }> };
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0058_mysterious_black_cat",
    );

    const sql = readRepoFile(
      "packages/db/drizzle/0058_mysterious_black_cat.sql",
    );
    const referencedUniqueAt = sql.indexOf(
      'CREATE UNIQUE INDEX "sms_delivery_event_history_event_id_uq"',
    );
    const reviewedHistoryFkAt = sql.indexOf(
      'ADD CONSTRAINT "sms_delivery_event_history_reviewed_history_fk"',
    );
    expect(referencedUniqueAt).toBeGreaterThan(0);
    expect(reviewedHistoryFkAt).toBeGreaterThan(referencedUniqueAt);
    expect(sql).toContain('"reviewed_history_id" uuid');
    expect(sql).toContain("sms_delivery_event_history_reviewed_history_uq");
    expect(sql).toContain("sms_delivery_events_immutable");
    expect(sql).toContain("sms_delivery_event_history_immutable");
    expect(sql).toContain(
      "ALTER TABLE sms_delivery_events ENABLE ROW LEVEL SECURITY",
    );
    expect(sql).toContain(
      "GRANT SELECT, INSERT ON sms_delivery_events, sms_delivery_event_history TO openpims_app",
    );
  });

  it("creates lab tenant uniqueness before the event ledger references it", () => {
    const journal = JSON.parse(
      readRepoFile("packages/db/drizzle/meta/_journal.json"),
    ) as { entries?: Array<{ tag?: string }> };
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0059_daffy_darkstar",
    );

    const sql = readRepoFile("packages/db/drizzle/0059_daffy_darkstar.sql");
    const referencedUniqueAt = sql.indexOf(
      'CREATE UNIQUE INDEX "lab_results_practice_record_uq"',
    );
    const resultTenantFkAt = sql.indexOf(
      'ADD CONSTRAINT "lab_result_events_result_tenant_fk"',
    );
    expect(referencedUniqueAt).toBeGreaterThan(0);
    expect(resultTenantFkAt).toBeGreaterThan(referencedUniqueAt);
  });

  it("creates exact, immutable lab correction and replacement evidence", () => {
    const journal = JSON.parse(
      readRepoFile("packages/db/drizzle/meta/_journal.json"),
    ) as { entries?: Array<{ tag?: string }> };
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0060_warm_rawhide_kid",
    );

    const sql = readRepoFile("packages/db/drizzle/0060_warm_rawhide_kid.sql");
    const correctionSourceUniqueAt = sql.indexOf(
      'CREATE UNIQUE INDEX "clinical_record_corrections_practice_record_lab_source_uq"',
    );
    const exactCorrectionFkAt = sql.indexOf(
      'ADD CONSTRAINT "lab_result_replacements_correction_source_tenant_fk"',
    );
    expect(correctionSourceUniqueAt).toBeGreaterThan(0);
    expect(exactCorrectionFkAt).toBeGreaterThan(correctionSourceUniqueAt);
    expect(sql).not.toContain("ADD VALUE 'lab_result'");
    expect(sql).toContain(
      'ALTER TYPE "public"."clinical_correction_record_type" RENAME TO "clinical_correction_record_type_old"',
    );
    expect(sql).toContain(
      'CREATE TYPE "public"."clinical_correction_record_type" AS ENUM',
    );
    expect(sql).toContain(
      'USING "record_type"::text::"public"."clinical_correction_record_type"',
    );
    expect(sql).toContain("ELSIF NEW.record_type = 'lab_result' THEN");
    expect(sql).toContain("FROM public.lab_results source");
    expect(sql).toContain('CREATE TABLE "lab_result_replacements"');
    expect(sql).toContain(
      'CREATE UNIQUE INDEX "lab_result_replacements_source_uq"',
    );
    expect(sql).toContain(
      'CREATE UNIQUE INDEX "lab_result_replacements_replacement_uq"',
    );
    expect(sql).toContain(
      "pg_catalog.hashtextextended('lab-result-replacement-graph:' || NEW.practice_id::text, 0)",
    );
    expect(sql).toContain("WITH RECURSIVE descendants(id) AS");
    expect(sql).toContain(
      "Lab result replacement lineage cannot contain a cycle.",
    );
    expect(sql).toContain("Lab result replacement evidence is append-only");
    expect(sql).toContain("current_setting('app.ledger_maintenance', true)");
    expect(sql).toContain("current_user = (");
    expect(sql).toContain(
      'ALTER TABLE "lab_result_replacements" ENABLE ROW LEVEL SECURITY',
    );
    expect(sql).toContain(
      "GRANT SELECT, INSERT ON lab_result_replacements TO openpims_app",
    );
    expect(sql).toContain(
      "REVOKE ALL ON lab_result_replacements FROM authenticated",
    );
  });

  it("creates system-only verification email attempts and immutable delivery evidence", () => {
    const journal = JSON.parse(
      readRepoFile("packages/db/drizzle/meta/_journal.json"),
    ) as { entries?: Array<{ tag?: string }> };
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0062_ambitious_moon_knight",
    );

    const sql = readRepoFile(
      "packages/db/drizzle/0062_ambitious_moon_knight.sql",
    );
    expect(sql).toContain('CREATE TABLE "auth_email_attempts"');
    expect(sql).toContain('CREATE TABLE "auth_email_delivery_events"');
    expect(sql).toContain('CREATE TABLE "auth_email_webhook_conflicts"');
    expect(sql).toContain(
      'CREATE TABLE "auth_email_provider_identity_conflicts"',
    );
    expect(sql).toContain("auth_email_attempts_outcome_shape_check");
    expect(sql).toContain("auth_email_attempts_state_guard");
    expect(sql).toContain("guard_auth_email_attempt_mutation");
    expect(sql).toContain("Auth email attempt identity is immutable");
    expect(sql).toContain(
      "Auth email attempt state transition is not permitted",
    );
    expect(sql).toContain("OLD.outcome = 'outcome_unknown'");
    expect(sql).toContain("NEW.outcome = 'accepted'");
    expect(sql).toContain(
      "Auth email attempts may only be deleted during owner maintenance",
    );
    expect(sql).toContain("\"provider\" in ('resend', 'console')");
    expect(sql).toContain("auth_email_delivery_events_attribution_shape_check");
    expect(sql).toContain(
      "auth_email_delivery_events_raw_body_fingerprint_check",
    );
    expect(sql).toContain('"raw_body_fingerprint" varchar(64) NOT NULL');
    expect(sql).toContain("'^[0-9a-f]{64}$'");
    expect(sql).toContain("auth_email_delivery_events_immutable");
    expect(sql).toContain("auth_email_webhook_conflicts_identity_uq");
    expect(sql.indexOf("auth_email_delivery_events_webhook_uq")).toBeLessThan(
      sql.indexOf("auth_email_webhook_conflicts_webhook_fk"),
    );
    expect(sql).toContain("auth_email_webhook_conflicts_immutable");
    expect(sql).toContain("auth_email_provider_identity_conflicts_immutable");
    expect(sql).toContain(
      "auth_email_provider_identity_conflicts_distinct_id_check",
    );
    expect(sql).toContain(
      "auth_email_provider_identity_conflicts_id_shape_check",
    );
    expect(sql).toContain(
      "auth_email_webhook_conflicts_raw_body_fingerprint_check",
    );
    expect(sql).toContain(
      "ALTER TABLE auth_email_attempts ENABLE ROW LEVEL SECURITY",
    );
    expect(sql).toContain(
      "ALTER TABLE auth_email_delivery_events ENABLE ROW LEVEL SECURITY",
    );
    expect(sql).toContain(
      "ALTER TABLE auth_email_webhook_conflicts ENABLE ROW LEVEL SECURITY",
    );
    expect(sql).toContain(
      "ALTER TABLE auth_email_provider_identity_conflicts ENABLE ROW LEVEL SECURITY",
    );
    expect(sql).toContain(
      "GRANT SELECT, INSERT, UPDATE ON auth_email_attempts TO openpims_app",
    );
    expect(sql).toContain(
      "GRANT SELECT, INSERT ON auth_email_delivery_events, auth_email_webhook_conflicts, auth_email_provider_identity_conflicts TO openpims_app",
    );
    expect(sql).not.toMatch(
      /recipient|verify_url|auth_token|subject|html|\bto\b varchar/i,
    );

    const reset = readRepoFile("packages/db/reset.ts");
    expect(reset).toContain('"auth_email_delivery_events"');
    expect(reset).toContain('"auth_email_webhook_conflicts"');
    expect(reset).toContain('"auth_email_provider_identity_conflicts"');
    expect(reset).toContain('"auth_email_attempts"');
    expect(reset.indexOf('"auth_email_webhook_conflicts"')).toBeLessThan(
      reset.indexOf('"auth_email_delivery_events"'),
    );
    expect(reset.indexOf('"auth_email_delivery_events"')).toBeLessThan(
      reset.indexOf('"auth_email_attempts"'),
    );

    const rls = readRepoFile("packages/db/rls/enable-rls.sql");
    expect(rls).toContain("CREATE POLICY system_only ON auth_email_attempts");
    expect(rls).toContain(
      "CREATE POLICY system_only ON auth_email_delivery_events",
    );
    expect(rls).toContain(
      "CREATE POLICY system_only ON auth_email_webhook_conflicts",
    );
    expect(rls).toContain(
      "CREATE POLICY system_only ON auth_email_provider_identity_conflicts",
    );
    expect(rls).toContain(
      "REVOKE ALL ON auth_email_attempts, auth_email_delivery_events, auth_email_webhook_conflicts, auth_email_provider_identity_conflicts FROM openpims_app",
    );
  });

  it("creates an immutable, tenant-safe SOAP draft/final/addendum ledger", () => {
    const journal = JSON.parse(
      readRepoFile("packages/db/drizzle/meta/_journal.json"),
    ) as { entries?: Array<{ tag?: string }> };
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0063_modern_starbolt",
    );

    const sql = readRepoFile("packages/db/drizzle/0063_modern_starbolt.sql");
    expect(sql).toContain('CREATE TYPE "public"."soap_note_status"');
    expect(sql).toContain('CREATE TABLE "soap_note_addenda"');
    expect(sql).toContain("soap_notes_active_appointment_draft_uq");
    expect(sql).toContain("guard_soap_note_lifecycle");
    expect(sql).toContain(
      "Only a draft from an open, unsigned encounter may be discarded.",
    );
    expect(sql).toContain(
      "CREATE CONSTRAINT TRIGGER soap_notes_appointment_invariant",
    );
    expect(sql).toContain("DEFERRABLE INITIALLY DEFERRED");
    expect(sql).toContain("CONSTRAINT = 'soap_notes_appointment_invariant'");
    expect(sql).toContain("source.status = 'finalized'");
    expect(sql).toContain("SOAP addenda are immutable");
    expect(sql).toContain("restore_soap_note_addendum");
    const addendumGuard = sql.slice(
      sql.indexOf("CREATE OR REPLACE FUNCTION guard_soap_note_addendum"),
      sql.indexOf("CREATE TRIGGER soap_note_addenda_guard"),
    );
    expect(addendumGuard).toContain("NEW.created_at < source_finalized_at");
    expect(addendumGuard).toContain("NEW.created_at > pg_catalog.now()");
    expect(addendumGuard).toContain("pg_catalog.sha256");
    expect(
      addendumGuard.indexOf("SOAP addendum payload hash is invalid."),
    ).toBeLessThan(addendumGuard.indexOf("app.ledger_maintenance"));
    const restoreFunction = sql.slice(
      sql.indexOf("CREATE OR REPLACE FUNCTION restore_soap_note_addendum"),
      sql.indexOf("REVOKE ALL ON FUNCTION restore_soap_note_addendum"),
    );
    expect(restoreFunction).toContain(
      "p_practice_id IS DISTINCT FROM nullif(current_setting('app.current_practice_id', true), '')::uuid",
    );
    expect(restoreFunction).not.toContain("app.rls_bypass");
    expect(restoreFunction).toContain("p_created_at < source_finalized_at");
    expect(restoreFunction).toContain("p_created_at > pg_catalog.now()");
    expect(restoreFunction).toContain("p_created_at > correction_created_at");
    expect(restoreFunction).toContain("pg_catalog.sha256");
    expect(restoreFunction).toContain(
      "SOAP addendum restore payload hash is invalid.",
    );
    expect(restoreFunction).toContain(
      "RETURNS TABLE(result_id uuid, was_inserted boolean)",
    );
    expect(restoreFunction).toContain(
      "existing_addendum.created_at IS DISTINCT FROM p_created_at",
    );
    expect(restoreFunction).toContain(
      "existing_addendum.author_name IS DISTINCT FROM p_author_name",
    );
    expect(restoreFunction).toContain(
      "existing_addendum.content IS DISTINCT FROM p_content",
    );
    expect(sql).toContain(
      "GRANT SELECT, INSERT ON soap_note_addenda TO openpims_app",
    );
    expect(sql).toContain(
      "Cannot enforce encounter SOAP lifecycle: historical appointments contain conflicting active documentation.",
    );
    expect(
      sql.match(
        /MESSAGE = 'Cannot enforce encounter SOAP lifecycle: historical appointments contain conflicting active documentation\.'/g,
      ),
    ).toHaveLength(1);
    expect(sql).toContain("'{demoData,soapNoteIds}'");
    expect(sql).toContain("'{demoData,appointmentIds}'");
    expect(sql).toContain("'{demoData,patientIds}'");
    expect(sql).toContain("note.patient_id::text IN");
    expect(sql).toContain(
      "WHEN pg_catalog.jsonb_typeof(practice.settings #> '{demoData,soapNoteIds}') = 'array'",
    );
    expect(
      sql.match(/CROSS JOIN LATERAL pg_catalog\.jsonb_array_elements_text\(/g),
    ).toHaveLength(1);
    expect(sql).not.toContain(
      "jsonb_array_elements_text(\n\t\tCROSS JOIN LATERAL",
    );
  });

  it("creates exact, immutable SOAP replacement lineage", () => {
    const journal = JSON.parse(
      readRepoFile("packages/db/drizzle/meta/_journal.json"),
    ) as { entries?: Array<{ tag?: string }> };
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0064_rainy_spacker_dave",
    );

    const sql = readRepoFile("packages/db/drizzle/0064_rainy_spacker_dave.sql");
    const correctionSourceUniqueAt = sql.indexOf(
      'CREATE UNIQUE INDEX "clinical_record_corrections_practice_record_soap_source_uq"',
    );
    const exactCorrectionFkAt = sql.indexOf(
      'ADD CONSTRAINT "soap_note_replacements_correction_source_tenant_fk"',
    );
    expect(correctionSourceUniqueAt).toBeGreaterThan(0);
    expect(exactCorrectionFkAt).toBeGreaterThan(0);
    expect(exactCorrectionFkAt).toBeGreaterThan(correctionSourceUniqueAt);
    expect(sql).toContain('CREATE TABLE "soap_note_replacements"');
    expect(sql).toContain(
      'CREATE UNIQUE INDEX "soap_note_replacements_source_uq"',
    );
    expect(sql).toContain(
      'CREATE UNIQUE INDEX "soap_note_replacements_replacement_uq"',
    );
    expect(sql).toContain(
      'CREATE UNIQUE INDEX "soap_note_replacements_operation_uq"',
    );
    expect(sql).toContain(
      '"soap_note_replacements"."actor_name" = btrim("soap_note_replacements"."actor_name")',
    );
    expect(sql).toContain(
      "pg_catalog.hashtextextended('soap-note-replacement-graph:' || NEW.practice_id::text, 0)",
    );
    expect(sql).toContain("WITH RECURSIVE descendants(id) AS");
    expect(sql).toContain(
      "SOAP note replacement lineage cannot contain a cycle.",
    );
    expect(sql).toContain("source.status = 'finalized'");
    expect(sql).toContain("replacement.status = 'finalized'");
    expect(sql).toContain(
      "replacement.appointment_id IS NOT DISTINCT FROM source.appointment_id",
    );
    expect(sql).toContain("replacement.patient_id = source.patient_id");
    expect(sql).toContain("replacement.finalized_by = NEW.actor_id");
    expect(sql).toContain("source.finalized_at <= correction.created_at");
    expect(sql).toContain("correction.created_at <= replacement.finalized_at");
    expect(sql).toContain("replacement_correction.created_at < NEW.created_at");
    const validationTrigger = sql.slice(
      sql.indexOf(
        "CREATE OR REPLACE FUNCTION validate_soap_note_replacement_insert",
      ),
      sql.indexOf("CREATE TRIGGER soap_note_replacements_validate"),
    );
    expect(validationTrigger).toContain("pg_catalog.sha256");
    expect(validationTrigger).toContain("'{\"patientId\":'");
    expect(validationTrigger).toContain("',\"sourceNoteId\":'");
    expect(validationTrigger).toContain("',\"actorId\":'");
    expect(validationTrigger).toContain("',\"reason\":'");
    expect(validationTrigger).toContain("',\"subjective\":'");
    expect(validationTrigger).toContain("',\"objective\":'");
    expect(validationTrigger).toContain("',\"assessment\":'");
    expect(validationTrigger).toContain("',\"plan\":'");
    expect(validationTrigger).toContain(
      "SOAP replacement payload hash is invalid.",
    );
    expect(validationTrigger).toContain(
      "coalesce(current_setting('app.soap_replacement_restore', true), '') = 'on'",
    );
    expect(validationTrigger).toContain("current_user = (");
    expect(validationTrigger).toContain("NEW.created_at <= source.deleted_at");
    expect(validationTrigger).toContain(
      "NEW.created_at <= replacement.deleted_at",
    );
    const restoreFunction = sql.slice(
      sql.indexOf("CREATE OR REPLACE FUNCTION restore_soap_note_replacement"),
      sql.indexOf("REVOKE ALL ON FUNCTION restore_soap_note_replacement"),
    );
    expect(restoreFunction).toContain("SECURITY DEFINER");
    expect(restoreFunction).toContain("SET search_path = ''");
    expect(restoreFunction).toContain(
      "p_practice_id IS DISTINCT FROM nullif(current_setting('app.current_practice_id', true), '')::uuid",
    );
    expect(restoreFunction).not.toContain("app.rls_bypass");
    expect(restoreFunction).toContain(
      "pg_catalog.set_config('app.soap_replacement_restore', 'on', true)",
    );
    expect(restoreFunction).toContain(
      "ON CONFLICT (practice_id, operation_id) DO NOTHING",
    );
    for (const replayField of [
      "id",
      "created_at",
      "correction_id",
      "source_soap_note_id",
      "replacement_soap_note_id",
      "actor_id",
      "actor_name",
      "operation_payload_hash",
    ]) {
      expect(restoreFunction).toContain(
        `existing_replacement.${replayField} IS DISTINCT FROM`,
      );
    }
    expect(sql).toContain(
      "REVOKE ALL ON FUNCTION restore_soap_note_replacement(uuid,timestamptz,uuid,uuid,uuid,uuid,uuid,text,uuid,text) FROM PUBLIC",
    );
    expect(sql).toContain(
      "GRANT EXECUTE ON FUNCTION restore_soap_note_replacement(uuid,timestamptz,uuid,uuid,uuid,uuid,uuid,text,uuid,text) TO openpims_app",
    );
    expect(sql).toContain("SOAP note replacement evidence is append-only");
    expect(sql).toContain("current_setting('app.ledger_maintenance', true)");
    expect(sql).toContain("current_user = (");
    expect(sql).toContain(
      "ALTER TABLE soap_note_replacements ENABLE ROW LEVEL SECURITY",
    );
    expect(sql).toContain(
      "GRANT SELECT, INSERT ON soap_note_replacements TO openpims_app",
    );
    expect(sql).toContain(
      "REVOKE ALL ON soap_note_replacements FROM authenticated",
    );

    const reset = readRepoFile("packages/db/reset.ts");
    expect(reset).toContain('"soap_note_replacements"');
    expect(reset.indexOf('"soap_note_replacements"')).toBeLessThan(
      reset.indexOf('"clinical_record_corrections"'),
    );

    const rls = readRepoFile("packages/db/rls/enable-rls.sql");
    expect(rls).toContain("'soap_note_replacements'");
    expect(rls).toContain(
      "GRANT SELECT, INSERT ON soap_note_replacements TO openpims_app",
    );
    expect(rls).toContain(
      "REVOKE ALL ON FUNCTION restore_soap_note_replacement(uuid,timestamptz,uuid,uuid,uuid,uuid,uuid,text,uuid,text) FROM PUBLIC",
    );
    expect(rls).toContain(
      "GRANT EXECUTE ON FUNCTION restore_soap_note_replacement(uuid,timestamptz,uuid,uuid,uuid,uuid,uuid,text,uuid,text) TO openpims_app",
    );
  });

  it("creates a PHI-free append-only carrier-registration lifecycle ledger", () => {
    const journal = JSON.parse(
      readRepoFile("packages/db/drizzle/meta/_journal.json"),
    ) as { entries?: Array<{ tag?: string }> };
    expect(journal.entries?.map((entry) => entry.tag)).toContain(
      "0065_sudden_kabuki",
    );

    const sql = readRepoFile("packages/db/drizzle/0065_sudden_kabuki.sql");
    const tableDefinition = sql.match(
      /CREATE TABLE "messaging_registration_events" \([\s\S]*?\n\);/,
    )?.[0];
    expect(tableDefinition).toBeDefined();
    expect(tableDefinition).not.toMatch(
      /"(tax_id|patient_id|client_id|provider_payload|error|detail)"|\bjsonb\b/,
    );
    expect(sql).toContain(
      "messaging_registration_events_registration_tenant_fk",
    );
    expect(
      sql.indexOf(
        'CREATE UNIQUE INDEX "messaging_registrations_practice_id_uq"',
      ),
    ).toBeLessThan(
      sql.indexOf(
        'ADD CONSTRAINT "messaging_registration_events_registration_tenant_fk"',
      ),
    );
    expect(sql).toContain("messaging_registration_events_location_tenant_fk");
    expect(sql).toContain("messaging_registration_events_actor_tenant_fk");
    expect(sql).toContain("messaging_registration_events_shape_check");
    expect(sql).toContain("pg_catalog.pg_advisory_xact_lock");
    expect(sql).toContain(
      "Messaging registration event must match the exact active carrier projection.",
    );
    expect(sql).toContain(
      "Messaging registration event must continue the durable carrier status chain.",
    );
    expect(sql).toContain("messaging_registration_events_immutable");
    expect(sql).toContain("app.ledger_maintenance");
    expect(sql).toContain(
      "ALTER TABLE messaging_registration_events ENABLE ROW LEVEL SECURITY",
    );
    expect(sql).toContain(
      "GRANT SELECT, INSERT ON messaging_registration_events TO openpims_app",
    );
    expect(sql).toContain(
      "REVOKE ALL ON messaging_registration_events FROM authenticated",
    );

    const reset = readRepoFile("packages/db/reset.ts");
    expect(reset).toContain('"messaging_registration_events"');

    const rls = readRepoFile("packages/db/rls/enable-rls.sql");
    expect(rls).toContain("'messaging_registration_events'");
    expect(rls).toContain(
      "GRANT SELECT, INSERT ON messaging_registration_events TO openpims_app",
    );
  });

  it("canonically reconciles demo's dormant backup and MFA schema without data replay", () => {
    const journal = JSON.parse(
      readRepoFile("packages/db/drizzle/meta/_journal.json"),
    ) as { entries: Array<{ idx: number; tag: string; when: number }> };
    const entry = journal.entries.find((candidate) => candidate.idx === 100);
    expect(entry?.tag).toBe("0100_small_kylun");
    // Drizzle orders pending migrations by this timestamp. It must remain
    // newer than demo's rogue 0101 timestamp so the reconciliation is not
    // skipped merely because that non-main ledger entry already exists.
    expect(entry?.when).toBeGreaterThan(1_788_016_103_861);

    const migration = readRepoFile(
      "packages/db/drizzle/0100_small_kylun.sql",
    );
    expect(migration).toContain(
      "0100 reconciliation refused: public.backup_run_status has an incompatible shape",
    );
    expect(migration).toContain(
      "0100 reconciliation refused: public.backup_runs has incompatible columns",
    );
    expect(migration).toContain(
      "0100 reconciliation refused: public.users.% has an incompatible shape",
    );
    expect(migration).toContain("LOCK TABLE public.backup_runs");
    expect(migration).toContain("LOCK TABLE public.users");
    expect(migration).toContain(
      "CREATE TYPE public.backup_run_status AS ENUM ('ok', 'degraded', 'failed')",
    );
    expect(migration).toContain("ADD COLUMN IF NOT EXISTS mfa_secret_encrypted");
    expect(migration).toContain("users_mfa_active_shape_check");
    expect(migration).toContain("users_mfa_pending_shape_check");
    expect(migration).toContain("users_mfa_totp_counter_check");
    expect(migration).toContain(
      "ALTER TABLE public.backup_runs ENABLE ROW LEVEL SECURITY",
    );
    expect(migration).toContain(
      "GRANT SELECT, INSERT ON TABLE public.backup_runs TO openpims_app",
    );
    expect(migration).not.toMatch(/\b(?:UPDATE|DELETE)\s+public\.(?:users|backup_runs)\b/i);
    expect(migration).not.toMatch(
      /cron\.schedule|CREATE\s+(?:OR\s+REPLACE\s+)?FUNCTION\s+[^\s(]*(?:totp|mfa)|CREATE\s+TRIGGER\s+[^\s]*(?:totp|mfa)/i,
    );

    const fixture = readRepoFile(
      "packages/db/fixtures/demo-rogue-0099-0101.sql",
    );
    expect(fixture.match(/10000000-0000-4000-8000-00000000000[1-3]/g)).toHaveLength(
      3,
    );
    expect(fixture).toContain("CREATE POLICY system_only");
    expect(fixture).toContain("users_mfa_active_shape_check");

    const rls = readRepoFile("packages/db/rls/enable-rls.sql");
    expect(rls).toContain(
      "CREATE POLICY system_only ON backup_runs",
    );
    expect(rls).toContain(
      "GRANT SELECT, INSERT ON backup_runs TO openpims_app",
    );
    expect(rls).not.toContain(
      "GRANT SELECT, INSERT, UPDATE ON backup_runs TO openpims_app",
    );

    const ci = readRepoFile(".github/workflows/ci.yml");
    expect(ci).toContain("db:demo-schema-reconciliation:test");
  });
});
